Relink kit for Paprium H700 alpha 0.5.2

Contains the exact application objects and zlib archive used by the release.
Corresponding source code is in source.tar.gz. Firmware SDL2 is dynamically
loaded and is not redistributed as a shared library.

Extract source.tar.gz into a separate directory and run:
  bash scripts/setup-toolchain.sh
  bash scripts/build.sh
You need Linux, Python 3, CMake, curl and standard build utilities.

To modify an LGPL component (for example blip_buf, ym3438 or NTSC filters),
edit the corresponding source and rebuild using the instructions above.
Copy the rebuilt .o for that component from build/aarch64/CMakeFiles/
paprium.dir/upstream/punchium/core/... into the same path in this relink kit.
All objects may also be replaced with the objects from a complete rebuild.
Set CC to the absolute path of the matching compiler, for example:
  export CC=/path/to/source/tools/aarch64--glibc--stable-2020.08-1/bin/aarch64-buildroot-linux-gnu-gcc
  sh relink.sh
The resulting paprium.aarch64 can replace the installed binary while the
game is closed. This operation preserves your game data and SRAM.

The project non-commercial terms do not replace the LGPL rights for the
LGPL-covered components. See licenses/THIRD-PARTY.txt and LGPL license text.
