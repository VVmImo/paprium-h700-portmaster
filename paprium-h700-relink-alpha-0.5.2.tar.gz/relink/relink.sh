#!/bin/sh
set -eu
cd -- "$(dirname -- "$0")"
: "${CC:?Set CC to the matching aarch64-buildroot-linux-gnu-gcc}"
"$CC" -march=armv8-a+simd -mtune=cortex-a53 @objects.rsp -lm -ldl -o paprium.aarch64
