#!/bin/bash
set -euo pipefail
PACKAGE_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"
FILES="$PACKAGE_DIR/files"
DEST=/userdata/roms/ports
if ! grep -qi knulli /etc/os-release; then echo 'Este pacote exige KNULLI.'; exit 1; fi
if [ "$(uname -m)" != aarch64 ]; then echo 'Este pacote exige ARM64 / aarch64.'; exit 1; fi
if pidof paprium.aarch64 >/dev/null 2>&1; then echo 'Fecha o Paprium antes de instalar.'; exit 1; fi
(cd "$FILES" && sha256sum -c payload.sha256)
"$FILES/paprium/paprium.aarch64" --version
if [ -L "$DEST/paprium" ] || [ -L "$DEST/Paprium.sh" ]; then
 echo 'Destino Paprium e um link simbolico: instalacao cancelada para preservar o destino.'; exit 1
fi
mkdir -p "$DEST/paprium"
cp -R "$FILES/paprium/." "$DEST/paprium/"
cp "$FILES/Paprium.sh" "$DEST/Paprium.sh"
chmod 755 "$DEST/Paprium.sh" "$DEST/paprium/"*.aarch64 "$DEST/paprium/"*.sh
mkdir -p "$DEST/paprium/gamedata/paprium" "$DEST/paprium/saves" "$DEST/paprium/conf"
sync
echo 'Instalacao concluida em /userdata/roms/ports.'
echo 'Atualiza a lista de jogos e abre Paprium no menu Ports.'
echo 'Experimental: ainda nao validado num aparelho com KNULLI.'
