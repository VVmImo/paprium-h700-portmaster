#!/bin/bash
set -u
BASE="$(cd -- "$(dirname -- "$0")" && pwd)"
PACKAGE="$BASE/paprium-knulli"
LOG="$PACKAGE/install.log"
XDG_DATA_HOME=${XDG_DATA_HOME:-$HOME/.local/share}
for candidate in /opt/system/Tools/PortMaster /opt/tools/PortMaster /userdata/system/.local/share/PortMaster /userdata/roms/ports/PortMaster "$XDG_DATA_HOME/PortMaster" /roms/ports/PortMaster; do
 if [ -f "$candidate/control.txt" ]; then controlfolder="$candidate"; break; fi
done
if [ -z "${controlfolder:-}" ]; then echo 'Instala primeiro o PortMaster.'; exit 1; fi
source "$controlfolder/control.txt"
[ ! -f "$controlfolder/mod_${CFW_NAME:-}.txt" ] || source "$controlfolder/mod_${CFW_NAME:-}.txt"
get_controls
finish_install() { if declare -F pm_message_end >/dev/null; then pm_message_end; fi; pm_finish; }
trap finish_install EXIT
if declare -F pm_message >/dev/null; then pm_message 'Installing Paprium. Please wait...'; fi
if bash "$PACKAGE/install.sh" >"$LOG" 2>&1; then
 if declare -F pm_message >/dev/null; then pm_message 'Paprium installed. Update gamelists, then open Paprium in Ports.'; fi
else
 if declare -F pm_message >/dev/null; then pm_message 'Paprium install failed. See paprium-knulli/install.log.'; fi
 exit 1
fi
