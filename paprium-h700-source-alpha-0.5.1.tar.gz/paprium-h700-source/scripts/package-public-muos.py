from pathlib import Path
import zipfile,hashlib
p=Path(__file__).resolve().parents[1]
out=p/'dist/Paprium-H700-muOS-alpha-0.5.1.muxupd'
with zipfile.ZipFile(p/'dist/paprium-h700-alpha-0.5.1.zip') as source,zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as target:
 for name in source.namelist():
  if name.endswith('/') or name.startswith(('paprium/gamedata/','paprium/saves/','paprium/conf/')):continue
  assert not name.lower().endswith(('.bin','.mp3','.wav'))
  info=zipfile.ZipInfo('mnt/union/ROMS/Ports/'+name,(2026,10,18,0,0,0));info.create_system=3
  info.external_attr=source.getinfo(name).external_attr;info.compress_type=zipfile.ZIP_DEFLATED
  target.writestr(info,source.read(name))
 target.writestr('mnt/union/ROMS/Ports/paprium/INSTALAR.txt','''Instalador completo Paprium H700 alpha 0.5.1, sem dados do jogo.
Instalar no Archive Manager. Destino unificado: /mnt/union/ROMS/Ports (SD1 ou SD2). Consulte MANUAL-DE-INSTALACAO.txt.
Fornecer paprium/gamedata/paprium.bin e os MP3 ou WAV com os nomes de TRACKS.txt em paprium/gamedata/paprium/.
Ao abrir Paprium.sh, os WAV em falta sao criados automaticamente a partir dos MP3.
Este arquivo nao contem ROM nem musicas do jogo.
''')
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for suffix in ['Paprium.sh','paprium/paprium.aarch64','paprium/paprium-convert.aarch64','paprium/prepare-music.sh','paprium/music-tracks.txt','paprium/source.tar.gz']:
  assert 'mnt/union/ROMS/Ports/'+suffix in z.namelist()
sha=hashlib.sha256(out.read_bytes()).hexdigest();out.with_suffix('.muxupd.sha256').write_text(sha+'  '+out.name+'\n')
print('Complete installer verified:',out.name,out.stat().st_size,sha)
