from pathlib import Path
import zipfile,tarfile,io,hashlib,json
p=Path(__file__).resolve().parents[1];version='0.5.1';prefix='paprium-knulli'
files={}
with zipfile.ZipFile(p/f'dist/paprium-h700-alpha-{version}.zip') as z:
 for name in z.namelist():
  if name.endswith('/') or name.startswith(('paprium/gamedata/','paprium/saves/','paprium/conf/')):continue
  if name in ['Paprium.sh','prepare-music.sh','music-tracks.txt']:continue
  files[prefix+'/files/'+name]=z.read(name)
files[prefix+'/files/Paprium.sh']=(p/'package-knulli/Paprium.sh').read_bytes()
files[prefix+'/files/paprium/MANUAL-KNULLI.txt']=(p/'MANUAL-KNULLI.txt').read_bytes()
meta=json.loads(files[prefix+'/files/paprium/port.json']);meta['attr']['desc']='KNULLI experimental H700 package. NOT hardware-tested on KNULLI.';files[prefix+'/files/paprium/port.json']=(json.dumps(meta,indent=2)+'\n').encode()
files[prefix+'/files/paprium/BUILD-INFO.txt']+=b'KNULLI launcher variant: no hardware validation; use MANUAL-KNULLI.txt.\n'
manifest=''.join(hashlib.sha256(data).hexdigest()+'  '+name.removeprefix(prefix+'/files/')+'\n' for name,data in sorted(files.items()))
files[prefix+'/files/payload.sha256']=manifest.encode()
files[prefix+'/install.sh']=(p/'package-knulli/install.sh').read_bytes()
files['Instalar Paprium.sh']=(p/'package-knulli/Instalar Paprium.sh').read_bytes()
files[prefix+'/MANUAL-KNULLI.txt']=(p/'MANUAL-KNULLI.txt').read_bytes()
out=p/f'dist/Paprium-H700-KNULLI-alpha-{version}-EXPERIMENTAL.tar.gz'
with tarfile.open(out,'w:gz',compresslevel=6) as tar:
 for name,data in sorted(files.items()):
  assert '..' not in name.split('/') and not name.startswith('/')
  assert not name.lower().endswith(('.bin','.mp3','.wav','.srm'))
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o755 if name.endswith(('.sh','.aarch64')) else 0o644;info.mtime=1792281600;tar.addfile(info,io.BytesIO(data))
sha=hashlib.sha256(out.read_bytes()).hexdigest();out.with_name(out.name+'.sha256').write_text(sha+'  '+out.name+'\n');print(out.name,out.stat().st_size,sha)
