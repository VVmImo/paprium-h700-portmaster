from pathlib import Path
import re, json
p=Path(__file__).resolve().parents[1]
s=(p/'upstream/punchium/core/cart_hw/punchium.h').read_text()
block=s[s.index('static const char* track_names[]'):s.index('if (track < 0x01')]
tracks=[(int(a,16),b+'.wav') for a,b in re.findall(r'\[0x([0-9A-Fa-f]+)\]\s*=\s*"([^"]+)"',block)]
text='Músicas fornecidas pelo utilizador. Nomes exatos esperados em gamedata/paprium/:\n\n'+'\n'.join(name for _,name in tracks)+'\n'
(p/'docs/TRACKS.txt').write_text(text)
(p/'docs/tracks.json').write_text(json.dumps([{'id':i,'file':name} for i,name in tracks],ensure_ascii=False,indent=2)+'\n')
print(len(tracks),'track names extracted from selected mapper')
