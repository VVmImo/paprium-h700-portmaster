from pathlib import Path
import zipfile,tarfile,io,hashlib,json
p=Path(__file__).resolve().parents[1]
assets=['Paprium-H700-muOS-alpha-0.5.1.muxupd','paprium-h700-alpha-0.5.1.zip','Paprium-H700-KNULLI-alpha-0.5.1-EXPERIMENTAL.tar.gz']
report=[]
for asset in assets:
 f=p/'dist'/asset
 if asset.endswith('.tar.gz'):
  with tarfile.open(f) as t: files={m.name:t.extractfile(m).read() for m in t.getmembers() if m.isfile()}
 else:
  with zipfile.ZipFile(f) as z: assert z.testzip() is None;files={n:z.read(n) for n in z.namelist() if not n.endswith('/')}
 assert all(not n.startswith('/') and '..' not in Path(n).parts for n in files)
 assert all(not n.lower().endswith(('.bin','.mp3','.wav','.srm','.part')) for n in files)
 source=next(data for name,data in files.items() if name.endswith('/source.tar.gz'))
 with tarfile.open(fileobj=io.BytesIO(source)) as t:
  names=t.getnames()
  assert any(n.endswith('/licenses/LGPL-2.1-or-later.txt') for n in names)
  assert any(n.endswith('/src/sfx_filter.h') for n in names)
  assert any(n.endswith('/scripts/package-knulli.py') for n in names)
  assert all('/.git/' not in n and '/tools/' not in n and '/logs/' not in n and '/gamedata/' not in n and '/roms/' not in n for n in names)
  for n in names:
   if n.lower().endswith(('.mp3','.wav')):assert '/tests/converter-fixtures/' in n,n
 assert any(n.endswith('/relink.tar.gz') for n in files)
 assert any(n.endswith('/licenses/THIRD-PARTY.txt') for n in files)
 assert any(n.endswith('/licenses/LGPL-2.1-or-later.txt') for n in files)
 sha=hashlib.sha256(f.read_bytes()).hexdigest();report.append({'asset':asset,'bytes':f.stat().st_size,'sha256':sha,'checks_passed':True})
(p/'dist/SHA256SUMS-public.txt').write_text(''.join(r['sha256']+'  '+r['asset']+'\n' for r in report))
(p/'logs/public-release-audit.json').write_text(json.dumps({'passed':True,'assets':report},indent=2)+'\n');print(json.dumps(report,indent=2))
