from pathlib import Path
import tarfile,hashlib,json,subprocess,os,shlex
p=Path(__file__).resolve().parents[1];root=p/'build/knulli-package-test';root.mkdir(parents=True,exist_ok=True)
archive=p/'dist/Paprium-H700-KNULLI-alpha-0.5.1-EXPERIMENTAL.tar.gz'
with tarfile.open(archive) as tar:
 assert all(not n.name.startswith('/') and '..' not in Path(n.name).parts for n in tar.getmembers())
 tar.extractall(root,filter='data')
package=root/'paprium-knulli';dest=root/'userdata/roms/ports';game=dest/'paprium';(game/'gamedata').mkdir(parents=True,exist_ok=True);(game/'saves').mkdir(exist_ok=True)
(game/'gamedata/paprium.bin').write_bytes(b'private test data sentinel, not a ROM');(game/'saves/paprium.srm').write_bytes(b'keep existing save')
release=root/'os-release';release.write_text('ID=knulli\n');sysroot=subprocess.check_output([str(p/'tools/aarch64--glibc--stable-2020.08-1/bin/aarch64-buildroot-linux-gnu-gcc'),'-print-sysroot'],text=True).strip()
s=(package/'install.sh').read_text().replace('/etc/os-release',str(release)).replace('DEST=/userdata/roms/ports','DEST='+shlex.quote(str(dest))).replace('"$(uname -m)"','"aarch64"').replace('"$FILES/paprium/paprium.aarch64" --version','qemu-aarch64 -L '+shlex.quote(sysroot)+' "$FILES/paprium/paprium.aarch64" --version')
test_script=root/'test-install.sh';test_script.write_text(s.replace('PACKAGE_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"','PACKAGE_DIR='+shlex.quote(str(package))))
r=subprocess.run(['bash',str(test_script)],capture_output=True,text=True,timeout=60);assert r.returncode==0,r.stdout+r.stderr
assert (dest/'Paprium.sh').is_file() and (game/'paprium-convert.aarch64').is_file()
assert (game/'saves/paprium.srm').read_bytes()==b'keep existing save'
assert (game/'gamedata/paprium.bin').read_bytes()==b'private test data sentinel, not a ROM'
release.write_text('ID=other-firmware\n');r=subprocess.run(['bash',str(test_script)],capture_output=True,text=True,timeout=10);assert r.returncode!=0
release.write_text('ID=knulli\n');(package/'files/Paprium.sh').write_text('damaged payload')
r=subprocess.run(['bash',str(test_script)],capture_output=True,text=True,timeout=10);assert r.returncode!=0
assert (dest/'Paprium.sh').read_bytes()!=(package/'files/Paprium.sh').read_bytes()
for f in (p/'package-knulli').glob('*.sh'):subprocess.run(['bash','-n',str(f)],check=True)
report={'passed':True,'hardware_knulli_tested':False,'tests':['archive paths safe','installer copies complete software','existing ROM and save preserved','non-KNULLI firmware rejected','tampered payload rejected before replacement','shell syntax validated'],'method':'isolated local filesystem; architecture and OS checks redirected only in test copy; real ARM64 binary run via QEMU'}
(p/'logs/knulli-package-tests.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
