from pathlib import Path
import shlex,shutil,tarfile,subprocess,os
p=Path(__file__).resolve().parents[1];build=p/'build/aarch64';root=p/'build/relink';root.mkdir(parents=True,exist_ok=True)
link=shlex.split((build/'CMakeFiles/paprium.dir/link.txt').read_text())
objects=[x for x in link if x.endswith(('.o','.a'))]
assert objects and all(not Path(x).is_absolute() and '..' not in Path(x).parts for x in objects)
for name in objects:
 target=root/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(build/name,target)
(root/'objects.rsp').write_text('\n'.join(objects)+'\n')
(root/'relink.sh').write_text('''#!/bin/sh
set -eu
cd -- "$(dirname -- "$0")"
: "${CC:?Set CC to the matching aarch64-buildroot-linux-gnu-gcc}"
"$CC" -march=armv8-a+simd -mtune=cortex-a53 @objects.rsp -lm -ldl -o paprium.aarch64
''');(root/'relink.sh').chmod(0o755)
(root/'README.txt').write_text('''Relink kit for Paprium H700 alpha 0.5.1

Contains the exact application objects and zlib archive used by the release.
Corresponding source code is in source.tar.gz. Firmware SDL2 is dynamically
loaded and is not redistributed as a shared library.

Extract source.tar.gz into a separate directory and run:
  bash scripts/setup-toolchain.sh
  bash scripts/build.sh
You need Linux, Python 3, CMake, curl and standard build utilities.

To modify an LGPL component (for example blip_buf, ym3438 or NTSC filters),
edit the corresponding source and rebuild using the instructions above.
Copy the rebuilt .o for that component from build/aarch64/CMakeFiles/
paprium.dir/upstream/punchium/core/... into the same path in this relink kit.
All objects may also be replaced with the objects from a complete rebuild.
Set CC to the absolute path of the matching compiler, for example:
  export CC=/path/to/source/tools/aarch64--glibc--stable-2020.08-1/bin/aarch64-buildroot-linux-gnu-gcc
  sh relink.sh
The resulting paprium.aarch64 can replace the installed binary while the
game is closed. This operation preserves your game data and SRAM.

The project non-commercial terms do not replace the LGPL rights for the
LGPL-covered components. See licenses/THIRD-PARTY.txt and LGPL license text.
''')
cc=p/'tools/aarch64--glibc--stable-2020.08-1/bin/aarch64-buildroot-linux-gnu-gcc'
subprocess.run(['sh','relink.sh'],cwd=root,env=dict(os.environ,CC=str(cc)),check=True)
# Do not include the test-linked executable: the kit contains inputs only.
(root/'paprium.aarch64').unlink()
out=p/'package/paprium/relink.tar.gz'
with tarfile.open(out,'w:gz',compresslevel=6) as tar:
 for f in sorted(root.rglob('*')):
  if f.is_file():tar.add(f,arcname='relink/'+f.relative_to(root).as_posix())
print('Relink kit built and link command tested:',out.stat().st_size,'bytes')
