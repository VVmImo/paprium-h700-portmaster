from pathlib import Path
import json, hashlib, struct, wave, sys
p=Path(__file__).resolve().parents[1]
root=p/'gamedata'
rom=root/'paprium.bin'
if not rom.is_file():
 print('Falta gamedata/paprium.bin'); sys.exit(2)
data=rom.read_bytes()
if not 512 <= len(data) <= 33554432:
 print('Tamanho de ROM inválido'); sys.exit(2)
print('ROM bytes:',len(data),'SHA256:',hashlib.sha256(data).hexdigest())
product=data[0x180:0x18e].decode('ascii',errors='replace')
print('Produto:',product)
if 'T-574120-00' not in product:
 print('O cabeçalho não identifica a revisão esperada pelo mapper'); sys.exit(2)
missing=[]; bad=[]
for track in json.loads((p/'docs/tracks.json').read_text()):
 f=root/'paprium'/track['file']
 if not f.is_file(): missing.append(f.name); continue
 try:
  with wave.open(str(f),'rb') as w:
   if w.getnchannels() not in [1,2] or not 8000 <= w.getframerate() <= 48000 or not w.getnframes(): bad.append(f.name)
 except (wave.Error,EOFError): bad.append(f.name)
for name in missing: print('Falta WAV:',name)
for name in bad: print('WAV inválido/não PCM verificado:',name)
print('Verificação estrutural; não valida ponteiros internos do dump nem compatibilidade com o jogo.')
sys.exit(1 if missing or bad else 0)
