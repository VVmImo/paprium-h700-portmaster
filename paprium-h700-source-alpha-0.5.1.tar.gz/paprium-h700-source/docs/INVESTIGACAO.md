# Inspeção e escolha da base — 2026-10-18

Ramos remotos confirmados por `git ls-remote --heads`:

| Repositório | Ramo | Commit observado |
| --- | --- | --- |
| pav1388/Genesis-Plus-GX-PUNCHiUM | punchium | 3849f3d3432df1d6320574e73695dd379ecef2b3 |
| pav1388/Genesis-Plus-GX-PUNCHiUM | rom-glitcher | b3cae6885b8520c2a9691dd369b701b9dba7bd39 |
| Genesis64X/Genesis-Plus-G64X_PAPwiiUM | main | c38719b3c442e48c93dfebe130fe58110d554395 |
| Genesis64X/Genesis-Plus-G64X_PAPwiiUM | 1 | 7b9bf7283c89009e6befbf6d3a9ac0bdf674ea7d |

Escolha: ramo punchium fixado no commit acima. Inclui mapper, descodificação de
recursos, misturador de efeitos e integração com SRAM em `core/cart_hw/punchium.h`.
O mapper é selecionado em `core/cart_hw/md_cart.c` por `T-574120-00`. Os comandos
0xDF e 0xE0 copiam quatro bancos de 0x780 bytes entre RAM do cartucho e SRAM.
Não se usa o frontend libretro; o núcleo recebe um frontend SDL2 próprio.

PAPwiiUM tem um frontend dependente de Wii/libogc/devkitPPC. O README confirma
estado beta, WAV, glitches e gravação ainda em testes. É referência, não uma
base Linux pronta. `rom-glitcher` tem objetivo diferente. A PR libretro #378 é
referência histórica do suporte e das limitações, não prova de suporte upstream.

As alterações desta alpha incluem leitura de WAV com memória limitada, limite
correto no array de formatos, logger stdio em vez de libretro e correção da cache:
`memset` não inicializava valores uint32_t com o sentinela esperado; o algoritmo
anterior podia ficar num ciclo infinito na fronteira de idade dos elementos.
Usa-se substituição circular de duração limitada.

Dependências de execução: Linux ARM64/glibc, SDL2 do firmware com vídeo, áudio e
GameController, configuração de comandos e helpers do PortMaster. CHD e o
backend OGG de Mega-CD estão desativados nesta compilação. Outros módulos de
Mega-CD ainda podem ser compilados por dependências internas, mas o frontend
aceita Mega Drive e destina-se exclusivamente a Paprium.

Não foram lidas nem utilizadas pastas dos outros projetos após a instrução de
isolamento. Downloads, fontes, toolchain, builds e pacotes ficam neste projeto.
Os utilitários do sistema são usados para executar a compilação e os testes.

Fontes consultadas:
- https://github.com/pav1388/Genesis-Plus-GX-PUNCHiUM/tree/punchium
- https://github.com/libretro/Genesis-Plus-GX/pull/378
- https://github.com/Genesis64X/Genesis-Plus-G64X_PAPwiiUM
- https://portmaster.games/packaging.html
- https://toolchains.bootlin.com/downloads/releases/toolchains/aarch64/tarballs/
