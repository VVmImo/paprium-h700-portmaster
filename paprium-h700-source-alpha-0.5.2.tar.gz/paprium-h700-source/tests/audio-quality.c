#include <stdio.h>
#include <math.h>
#include <stdint.h>
#include "audio_output.h"
#include "pcm_interpolate.h"
#include "sfx_filter.h"
#define PI 3.14159265358979323846
int main(void) {
 pm_dc_blocker dc={0}; double mean=0,energy=0,ref=0;
 for(int i=0;i<144000;i++) {
  int16_t pcm[2]={(int16_t)(4000+5000*sin(2*PI*80*i/48000.0)),4000};
  pm_remove_dc(&dc,pcm,1);
  if(i>=96000){mean+=pcm[1];energy+=(double)pcm[0]*pcm[0];ref+=5000.0*5000.0/2;}
 }
 double loss=10*log10(energy/ref); mean/=48000;
 if(fabs(mean)>1 || fabs(loss)>0.1) return 1;
 double old_re=0,old_im=0,new_re=0,new_im=0,fund_re=0,fund_im=0;
 for(int i=0;i<48000;i++) {
  int a=(int)(12000*sin(2*PI*1000*(i/6)/8000.0));
  int b=(int)(12000*sin(2*PI*1000*(i/6+1)/8000.0));
  int v=pm_interpolate_pcm(a,b,i%6,6);
  double angle=2*PI*7000*i/48000.0;
  old_re+=a*cos(angle);old_im+=a*sin(angle);new_re+=v*cos(angle);new_im+=v*sin(angle);
  fund_re+=v*cos(2*PI*1000*i/48000.0);fund_im+=v*sin(2*PI*1000*i/48000.0);
 }
 double improvement=20*log10(hypot(old_re,old_im)/hypot(new_re,new_im));
 double fundamental=20*log10(2*hypot(fund_re,fund_im)/48000/12000);
 if(improvement<12 || fabs(fundamental)>1) return 2;
 if(pm_decode_pcm(0x80,1,0)!=0 || pm_decode_pcm(0x8f,2,0)!=0 || pm_decode_pcm(0x8f,2,1)!=28672) return 3;
 printf("DC remaining %.3f counts; 80Hz change %.4f dB; PCM image reduction %.2f dB; fundamental change %.2f dB\n",mean,loss,improvement,fundamental);
 double response[3]; const double tones[3]={80,1000,10000};
 for(int t=0;t<3;t++) {
  pm_sfx_filter filter={0}; double out_energy=0,in_energy=0;
  for(int i=0;i<96000;i++) {
   int left=(int)(10000*sin(2*PI*tones[t]*i/48000.0));int right=0,input=left;
   pm_filter_sfx(&filter,&left,&right);
   if(right!=0) return 4;
   if(i>=48000){out_energy+=(double)left*left;in_energy+=(double)input*input;}
  }
  response[t]=10*log10(out_energy/in_energy);
 }
 if(fabs(response[0])>0.01 || fabs(response[1])>0.1 || response[2]>-10) return 5;
 printf("SFX-only response: 80Hz %.4f dB, 1kHz %.3f dB, 10kHz %.2f dB; stereo isolation passed\n",response[0],response[1],response[2]);
 return 0;
}
