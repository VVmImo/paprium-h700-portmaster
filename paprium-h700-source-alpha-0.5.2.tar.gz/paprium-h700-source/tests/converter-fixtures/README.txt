Original synthetic test tones, generated for converter verification.
mono.mp3: 1 kHz sine, 44.1 kHz mono, 0.3 seconds.
stereo.mp3: 2 kHz sine, 48 kHz stereo, 0.3 seconds.
reference.wav: FFmpeg decoding/resampling of mono.mp3, PCM16 stereo 48 kHz.
These fixtures contain no Paprium game audio or other third-party music.
Distributed under the project's source license.
