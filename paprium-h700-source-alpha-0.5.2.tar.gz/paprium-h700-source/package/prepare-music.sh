#!/bin/bash
# Called before emulation. Arguments are absolute paths supplied by the launcher.

GAMEDIR=${1:?Missing game directory}
CONVERTER="$GAMEDIR/paprium-convert.aarch64"
MUSIC="$GAMEDIR/gamedata/paprium"
TRACKS="$GAMEDIR/music-tracks.txt"
lock="$MUSIC/.paprium-conversion-lock"
lock_acquired=0
cleanup() {
    if [ "$lock_acquired" -eq 1 ]; then
        rm -f "$lock/owner"
        rmdir "$lock" 2>/dev/null || true
    fi
    if declare -F pm_message_end >/dev/null; then pm_message_end; fi
}
trap cleanup EXIT
trap 'exit 130' INT TERM
notify() {
    if declare -F pm_message >/dev/null; then pm_message "$*"; else printf '%s\n' "$*"; fi
    printf '%s\n' "$*" > "$GAMEDIR/conf/conversion-status.txt"
}
[ -f "$TRACKS" ] && [ -x "$CONVERTER" ] || { echo 'Missing converter/track manifest'; exit 1; }
mkdir -p "$MUSIC" "$GAMEDIR/conf" || exit 1
needed=0
while IFS= read -r name || [ -n "$name" ]; do
    [ -n "$name" ] || continue
    wav="$MUSIC/$name.wav"
    if [ -f "$wav" ]; then
        "$CONVERTER" --check "$wav" || { notify "Invalid WAV; original preserved: $name.wav"; exit 1; }
        continue
    fi
    [ -f "$MUSIC/$name.mp3" ] || { notify "Missing music: $name.wav or $name.mp3"; exit 1; }
    needed=$((needed+1))
done < "$TRACKS"
[ "$needed" -gt 0 ] || { echo 'All WAV tracks present; no conversion needed.'; exit 0; }
boot_id=$(cat /proc/sys/kernel/random/boot_id)
if ! mkdir "$lock" 2>/dev/null; then
    owner_pid=; owner_boot=
    if [ -f "$lock/owner" ]; then read -r owner_pid owner_boot < "$lock/owner"; fi
    case "$owner_pid" in ''|*[!0-9]*) owner_pid= ;; esac
    if [ -n "$owner_pid" ] && [ "$owner_boot" = "$boot_id" ] && kill -0 "$owner_pid" 2>/dev/null; then
        echo 'Another music conversion is running.'; exit 1
    fi
    # Recover a lock left by an interrupted previous boot/conversion.
    rm -f "$lock/owner"
    rmdir "$lock" 2>/dev/null && mkdir "$lock" || { echo 'Cannot acquire music conversion lock.'; exit 1; }
fi
lock_acquired=1
printf '%s %s\n' "$BASHPID" "$boot_id" > "$lock/owner"
index=0
while IFS= read -r name || [ -n "$name" ]; do
    [ -n "$name" ] || continue
    [ ! -f "$MUSIC/$name.wav" ] || continue
    index=$((index+1))
    notify "Converting music $index/$needed: $name"
    "$CONVERTER" "$MUSIC/$name.mp3" "$MUSIC/$name.wav" || { notify "Conversion failed: $name. Check free space and log.txt."; exit 1; }
done < "$TRACKS"
notify 'Music preparation complete. Starting Paprium.'
