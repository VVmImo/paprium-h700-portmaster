#!/bin/bash
# Manual PortMaster launcher: native SDL2 input, graceful quit, no kill helper.
XDG_DATA_HOME=${XDG_DATA_HOME:-$HOME/.local/share}
for candidate in /opt/system/Tools/PortMaster /opt/tools/PortMaster "$XDG_DATA_HOME/PortMaster" /roms/ports/PortMaster; do
    if [ -f "$candidate/control.txt" ]; then controlfolder="$candidate"; break; fi
done
if [ -z "${controlfolder:-}" ]; then
    echo "PortMaster control.txt not found. Install/update PortMaster first."
    exit 1
fi
source "$controlfolder/control.txt"
[ ! -f "$controlfolder/mod_${CFW_NAME}.txt" ] || source "$controlfolder/mod_${CFW_NAME}.txt"
get_controls
GAMEDIR="$(cd -- "$(dirname -- "$0")" && pwd)/paprium"
# muOS unionfs may stall streaming reads; use the underlying card for all I/O.
case "$GAMEDIR" in
    /mnt/union/ROMS/*)
        relative="${GAMEDIR#/mnt/union/ROMS/}"
        for card in /mnt/sdcard /mnt/mmc; do
            if [ -f "$card/ROMS/$relative/paprium.aarch64" ]; then
                GAMEDIR="$card/ROMS/$relative"
                break
            fi
        done
        ;;
esac
if [ ! -d "$GAMEDIR" ]; then
    echo "Missing paprium directory next to Paprium.sh"
    exit 1
fi
cd "$GAMEDIR" || exit 1
exec > >(tee "$GAMEDIR/log.txt") 2>&1
echo "Paprium physical data path: $GAMEDIR"
finish() { pm_finish; }
trap finish EXIT
if [ "${DEVICE_ARCH:-$(uname -m)}" != aarch64 ]; then
    pm_message "Paprium alpha requires ARM64 (aarch64)."
    exit 1
fi
mkdir -p "$GAMEDIR/saves" "$GAMEDIR/conf"
export XDG_DATA_HOME="$GAMEDIR/conf"
export SDL_GAMECONTROLLERCONFIG="${sdl_controllerconfig:-${SDL_GAMECONTROLLERCONFIG:-}}"
export SDL_RENDER_SCALE_QUALITY=0
# Firmware supplies the SDL2 backend for muOS/H700. No foreign SDL library.
if [ ! -f "$GAMEDIR/gamedata/paprium.bin" ]; then
    pm_message "Copy your paprium.bin to paprium/gamedata. See README.txt."
    exit 1
fi
# Subshell keeps preparation traps and variables separate from the launcher.
if ! (trap - EXIT; source "$GAMEDIR/prepare-music.sh" "$GAMEDIR"); then
    pm_message "Music preparation failed. Supply the named WAV or MP3 files in gamedata/paprium. See log.txt."
    exit 1
fi
pm_platform_helper "$GAMEDIR/paprium.aarch64"
"$GAMEDIR/paprium.aarch64" "$GAMEDIR/gamedata/paprium.bin" "$GAMEDIR/saves"
status=$?
if [ "$status" -ne 0 ]; then
    pm_message "Paprium failed (code $status). See paprium/log.txt."
fi
exit "$status"
