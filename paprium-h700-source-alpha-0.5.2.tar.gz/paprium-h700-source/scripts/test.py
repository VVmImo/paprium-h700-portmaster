from pathlib import Path
import os, subprocess, hashlib, time, signal, json
p=Path(__file__).resolve().parents[1]
root=p/'build/fixtures'
qemu=['qemu-aarch64','-L',os.environ['PM_TEST_SYSROOT'],str(p/'build/aarch64/paprium')]
env=dict(os.environ, SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',SDL_RENDER_DRIVER='software',SDL_JOYSTICK_ALLOW_BACKGROUND_EVENTS='1',LD_LIBRARY_PATH=str(p/'build/sdl-test-aarch64'))
report=[]
def run(args,code=0,tag=''):
 r=subprocess.run(qemu+list(map(str,args)),env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=40,cwd=p)
 (p/'logs'/('test-'+tag+'.log')).write_text(r.stdout)
 print(tag,':',r.returncode,flush=True)
 if r.returncode!=code: raise AssertionError(r.stdout)
 report.append({'test':tag,'exit':r.returncode,'passed':True})
 return r.stdout
run(['--version'],tag='version')
run(['--help'],tag='help')
run(['--test-wav',root],tag='wav-streaming')
run(['--test-controller'],tag='controller')
saves=root/'saves'; saves.mkdir(exist_ok=True)
f=saves/'paprium.srm'
# Only generated scratch saves are reset by these tests.
if f.exists(): f.unlink()
out=run([root/'test.bin',saves,'--frames','120'],tag='video-audio-sram')
assert 'first_pixel=e800' in out,out
assert 'Paprium audio: filter=off' in out,out
assert f.stat().st_size==65536
assert 0x5a in f.read_bytes(),'Test ROM SRAM write did not persist'
before=hashlib.sha256(f.read_bytes()).hexdigest()
out=run([root/'test-readonly.bin',saves,'--frames','30'],tag='sram-reopen')
assert 'sram_marker=5a' in out,out
assert hashlib.sha256(f.read_bytes()).hexdigest()==before
env['PAPRIUM_LEGACY_AUDIO_FILTER']='1'
out=run([root/'test-readonly.bin',saves,'--frames','3'],tag='legacy-audio-option')
assert 'Paprium audio: filter=legacy low-pass' in out,out
env.pop('PAPRIUM_LEGACY_AUDIO_FILTER')

bad=root/'bad-save'; bad.mkdir(exist_ok=True); (bad/'paprium.srm').write_bytes(b'keep me')
run([root/'test.bin',bad,'--frames','3'],4,'bad-save-preserved')
assert (bad/'paprium.srm').read_bytes()==b'keep me'
run([root/'missing.bin',saves],2,'missing-rom')
run([root/'test.bin',saves,'--frames','abc'],2,'bad-arguments')
# SIGTERM must unwind the frontend normally rather than losing pending writes.
log=p/'logs/test-sigterm.log'
with log.open('w') as output:
 proc=subprocess.Popen(qemu+[str(root/'test.bin'),str(saves),'--frames','10000'],env=env,stdout=output,stderr=subprocess.STDOUT,cwd=p)
 time.sleep(2)
 proc.send_signal(signal.SIGTERM)
 assert proc.wait(timeout=20)==0
assert 'result=0' in log.read_text()
report.append({'test':'sigterm','exit':0,'passed':True})
(p/'logs/test-results.json').write_text(json.dumps(report,indent=2)+'\n')
print('All ARM64 tests passed. Physical H700/Paprium validation remains pending.',flush=True)
