#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")/.."
export TMPDIR="$PWD/build/tmp" MAKEFLAGS="--jobserver-style=pipe"
mkdir -p "$TMPDIR" logs
python3 scripts/test-fixtures.py
sdk="$PWD/tools/aarch64--glibc--stable-2020.08-1"
export PM_TEST_SYSROOT
PM_TEST_SYSROOT=$("$sdk/bin/aarch64-buildroot-linux-gnu-gcc" -print-sysroot)
python3 scripts/test.py
bash -n package/Paprium.sh

python3 scripts/test-audio-quality.py
