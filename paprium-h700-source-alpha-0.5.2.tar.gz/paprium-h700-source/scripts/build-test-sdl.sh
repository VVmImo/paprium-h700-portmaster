#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")/.."
export TMPDIR="$PWD/build/tmp" MAKEFLAGS="--jobserver-style=pipe"
mkdir -p "$TMPDIR"
mkdir -p build/pkgconfig-empty
export PKG_CONFIG_LIBDIR="$PWD/build/pkgconfig-empty"
cmake -S upstream/SDL -B build/sdl-test-aarch64 -DCMAKE_TOOLCHAIN_FILE="$PWD/scripts/aarch64.cmake" -DCMAKE_BUILD_TYPE=Release -DSDL_TEST=OFF -DSDL_SHARED=ON -DSDL_STATIC=OFF -DSDL_X11=OFF -DSDL_WAYLAND=OFF -DSDL_KMSDRM=OFF -DSDL_ALSA=OFF -DSDL_PULSEAUDIO=OFF -DSDL_PIPEWIRE=OFF -DSDL_JACK=OFF -DSDL_SNDIO=OFF -DSDL_LIBSAMPLERATE=OFF -DSDL_OPENGL=OFF -DSDL_OPENGLES=OFF -DSDL_VULKAN=OFF -DSDL_HIDAPI=ON -DSDL_HIDAPI_LIBUSB=OFF -DSDL_VIRTUAL_JOYSTICK=ON -DSDL_DBUS=OFF -DSDL_IBUS=OFF -DSDL_LIBUDEV=OFF
cmake --build build/sdl-test-aarch64 --target SDL2 -j8
