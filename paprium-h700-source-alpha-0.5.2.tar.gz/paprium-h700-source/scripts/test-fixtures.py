from pathlib import Path
import struct, wave
p=Path(__file__).resolve().parents[1]
t=p/'build/fixtures'; (t/'paprium').mkdir(parents=True,exist_ok=True)
for name, channels, rate, n, vals in [
 ("02 90's Acid Dub Character Select",2,48000,9001,(1000,-1000)),
 ("08 90's Dance",1,44100,7001,(2000,)),
 ("42 1988 Commercial",1,96000,10,(3000,))]:
 with wave.open(str(t/'paprium'/(name+'.wav')),'wb') as w:
  w.setnchannels(channels); w.setsampwidth(2); w.setframerate(rate)
  if name.startswith('02 '):
   pcm=b''.join(struct.pack('<hh',(i%2000)-1000,1000-(i%2000)) for i in range(n))
  elif name.startswith('08 '):
   pcm=b''.join(struct.pack('<h',(i%4000)-2000) for i in range(n))
  else: pcm=struct.pack('<'+'h'*channels,*vals)*n
  w.writeframes(pcm)
rom=bytearray(65536)
struct.pack_into('>II',rom,0,0x00ff0000,0x200)
rom[0x100:0x110]=b'SEGA MEGA DRIVE '
rom[0x120:0x150]=b'PAPRIUM FRONTEND TEST'.ljust(48,b' ')
rom[0x150:0x180]=b'PAPRIUM FRONTEND TEST'.ljust(48,b' ')
rom[0x180:0x18e]=b'GM 00000000-00'
rom[0x190:0x1a0]=b'J6'.ljust(16,b' ')
struct.pack_into('>IIII',rom,0x1a0,0,len(rom)-1,0xff0000,0xffffff)
rom[0x1b0:0x1b4]=b'RA\xf8\x20'
struct.pack_into('>II',rom,0x1b4,0x200001,0x20ffff)
rom[0x1f0:0x200]=b'U'.ljust(16,b' ')
code=bytes.fromhex('46fc2700 33fc800400c00004 33fc817400c00004 33fc8f0200c00004 23fcc000000000c00004 33fc000e00c00000 13fc005a00200001 60fe')
rom[0x200:0x200+len(code)]=code
struct.pack_into('>H',rom,0x18e,sum(struct.unpack('>'+ 'H'*((len(rom)-512)//2),rom[512:]))&65535)
(t/'test.bin').write_bytes(rom)
# Second ROM performs no SRAM write: its exit state must come from the loaded save.
needle=bytes.fromhex('13fc005a00200001')
start=rom.index(needle,0x200)
rom[start:start+len(needle)]=bytes.fromhex('4e71')*4
(t/'test-readonly.bin').write_bytes(rom)
print('Generated original test ROM and WAV fixtures')
