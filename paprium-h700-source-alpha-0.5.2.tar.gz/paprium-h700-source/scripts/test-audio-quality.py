from pathlib import Path
import subprocess,json
p=Path(__file__).resolve().parents[1];sdk=p/'tools/aarch64--glibc--stable-2020.08-1'
cc=sdk/'bin/aarch64-buildroot-linux-gnu-gcc'
sysroot=subprocess.check_output([str(cc),'-print-sysroot'],text=True).strip()
subprocess.run([str(cc),'-O2','-I'+str(p/'src'),str(p/'tests/audio-quality.c'),'-lm','-o',str(p/'build/audio-quality-test')],check=True)
r=subprocess.run(['qemu-aarch64','-L',sysroot,str(p/'build/audio-quality-test')],capture_output=True,text=True,timeout=30)
report={'passed':r.returncode==0,'platform':'ARM64 under QEMU','hardware_listening_verified':False,'result':r.stdout,'stderr':r.stderr}
(p/'logs/audio-quality-tests.json').write_text(json.dumps(report,indent=2)+'\n');print(r.stdout);raise SystemExit(r.returncode)
