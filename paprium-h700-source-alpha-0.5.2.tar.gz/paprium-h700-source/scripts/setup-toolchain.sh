#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")/.."
mkdir -p downloads tools build/tmp
export TMPDIR="$PWD/build/tmp"
url=https://toolchains.bootlin.com/downloads/releases/toolchains/aarch64/tarballs/aarch64--glibc--stable-2020.08-1.tar.bz2
if [ ! -f downloads/toolchain.tar.bz2 ]; then
    curl -fL --retry 3 "$url" -o downloads/toolchain.tar.bz2
fi
python3 - <<'PY'
from pathlib import Path
import hashlib
expected = Path('downloads/toolchain.sha256').read_text().split()[0]
assert hashlib.sha256(Path('downloads/toolchain.tar.bz2').read_bytes()).hexdigest() == expected, 'Toolchain SHA256 mismatch'
print('Toolchain SHA256 OK')
PY
if [ ! -x tools/aarch64--glibc--stable-2020.08-1/bin/aarch64-buildroot-linux-gnu-gcc ]; then
    tar -xjf downloads/toolchain.tar.bz2 -C tools
fi
