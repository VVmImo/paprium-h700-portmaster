from pathlib import Path
import subprocess, json, tarfile, zipfile, hashlib, re, shutil, os
p=Path(__file__).resolve().parents[1]
dist=p/'dist'; dist.mkdir(exist_ok=True)
stage=p/'package'; game=stage/'paprium'
for d in ['gamedata/paprium','saves','conf','licenses']:(game/d).mkdir(parents=True,exist_ok=True)
results=json.loads((p/'logs/test-results.json').read_text())
assert results and all(t['passed'] for t in results),'Tests must pass before packaging'
sdk=p/'tools/aarch64--glibc--stable-2020.08-1'
prefix=sdk/'bin/aarch64-buildroot-linux-gnu-'
def capture(tool,*args):
 return subprocess.check_output([str(prefix)+tool,*map(str,args)],text=True,cwd=p)
binary=p/'build/aarch64/paprium'
elf=capture('readelf','-h',binary); deps=capture('readelf','-d',binary); versions=capture('readelf','--version-info',binary)
assert 'AArch64' in elf
minimum=max(set(re.findall(r'GLIBC_(\d+\.\d+)',versions)),key=lambda s:tuple(map(int,s.split('.'))))
needed=re.findall(r'Shared library: \[([^]]+)\]',deps)
commit=json.loads((p/'docs/source-lock.json').read_text())['punchium']
info=f'''Paprium H700 alpha 0.5.2
Build date: 2026-10-18
Core: pav1388/Genesis-Plus-GX-PUNCHiUM punchium {commit}
Architecture: AArch64, ARMv8-A SIMD, Cortex-A53 tuning
Toolchain: Bootlin stable 2020.08-1; GCC 9.3.0
Maximum required GLIBC symbol version: {minimum}
ELF NEEDED: {', '.join(needed)}
Runtime dlopen: libSDL2-2.0.so.0 from the firmware
zlib: 1.3.1 statically linked
SDL headers: 2.30.11; firmware ABI must provide the used SDL2 symbols
Test-only SDL2 dummy library is excluded from this package
muOS H700: user-tested on RG40XX H; audio improvement confirmed.
KNULLI: untested on hardware; experimental package only.
Full-game and two-player validation remain pending.
No game ROM/music is included
'''
(game/'BUILD-INFO.txt').write_text(info)
(game/'TEST-RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
shutil.copy2(binary,game/'paprium.aarch64')
shutil.copy2(p/'build/aarch64/paprium-convert',game/'paprium-convert.aarch64')
subprocess.run([str(prefix)+'strip',str(game/'paprium-convert.aarch64')],check=True)
shutil.copy2(p/'package/prepare-music.sh',game/'prepare-music.sh')
shutil.copy2(p/'package/music-tracks.txt',game/'music-tracks.txt')
assert json.loads((p/'logs/converter-tests.json').read_text())['passed']
shutil.copy2(p/'logs/converter-tests.json',game/'CONVERTER-TESTS.json')
assert json.loads((p/'logs/audio-quality-tests.json').read_text())['passed']
shutil.copy2(p/'logs/audio-quality-tests.json',game/'AUDIO-QUALITY-TESTS.json')
subprocess.run([str(prefix)+'strip',str(game/'paprium.aarch64')],check=True)
shutil.copy2(p/'README.md',game/'README.txt')
shutil.copy2(p/'INSTALL-MUOS.txt',game/'INSTALL-MUOS.txt')
shutil.copy2(p/'docs/TRACKS.txt',game/'TRACKS.txt')
for license_file in sorted((p/'licenses').glob('*.txt')):
 shutil.copy2(license_file,game/'licenses'/license_file.name)
shutil.copy2(p/'upstream/punchium/LICENSE.txt',p/'LICENSE.txt')
assert (game/'relink.tar.gz').is_file(), 'Run package-relink.py first'
metadata={'version':4,'name':'paprium-h700-alpha-0.5.2.zip','items':['Paprium.sh','paprium'],'items_opt':[], 'attr':{'title':'Paprium (H700 alpha)','porter':['VVmImo'],'desc':'Experimental integrated emulation using Genesis Plus GX PUNCHiUM. muOS user-tested; KNULLI hardware validation pending.','desc_md':None,'inst':'Supply your compatible paprium.bin and named WAV or MP3 music. Missing WAV files are converted automatically before the game. Read README.txt.','inst_md':None,'genres':['action'],'image':None,'rtr':False,'exp':True,'runtime':[],'store':[],'availability':'full','reqs':[],'arch':['aarch64'],'min_glibc':minimum}}
(game/'port.json').write_text(json.dumps(metadata,indent=2)+'\n')
# Source distribution is an allowlist: no tools, build outputs, logs, game data or .git.
source_files=[p/'tests/audio-quality.c',p/'CMakeLists.txt',p/'README.md',p/'INSTALL-MUOS.txt',p/'INSTALL-KNULLI.txt',p/'LICENSE.txt',p/'downloads/toolchain.sha256']
for base in ['src','licenses','package-knulli','tests/converter-fixtures','upstream/punchium/core','upstream/punchium/sdl','upstream/SDL','upstream/zlib']:
 for root,dirs,files in os.walk(p/base):
  dirs[:]=sorted(d for d in dirs if d not in ['.git','__pycache__'])
  for name in sorted(files):
   if base == 'upstream/SDL' and Path(name).suffix.lower() in ['.wav','.mp3','.ogg','.flac','.mid']: continue
   source_files.append(Path(root)/name)
for f in ['LICENSE.txt','README.md','sdl/Makefile.sdl2']:
 source_files.append(p/'upstream/punchium'/f)
for name in ['aarch64.cmake','build.sh','configure.py','setup-toolchain.sh','build-test-sdl.sh','test.sh','test.py','test-fixtures.py','tracks.py','check-gamedata.py','package.py','package-public-muos.py','package-knulli.py','package-relink.py','test-knulli-package.py','audit-public-release.py','test-audio-quality.py','test-converter.py']:
 source_files.append(p/'scripts'/name)
source_files += [p/'docs/INVESTIGACAO.md',p/'docs/TRACKS.txt',p/'docs/tracks.json',p/'docs/source-lock.json',p/'docs/h700-core.patch',stage/'Paprium.sh',stage/'prepare-music.sh',stage/'music-tracks.txt']
with tarfile.open(game/'source.tar.gz','w:gz',compresslevel=6) as tar:
 for f in sorted(set(source_files)):
  arc=str(f.relative_to(p))
  def filt(item):
   item.uid=item.gid=0; item.uname=item.gname=''; item.mtime=1792281600
   item.mode=0o755 if item.name.endswith('.sh') else 0o644
   return item
  tar.add(f,arcname='paprium-h700-source/'+arc,recursive=False,filter=filt)
archive=dist/'paprium-h700-alpha-0.5.2.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in [stage/'Paprium.sh',stage/'prepare-music.sh',stage/'music-tracks.txt']+sorted(game.rglob('*')):
  if f.is_file():
   arc=f.relative_to(stage).as_posix()
   # Do not accidentally include supplied data or existing saves.
   if arc.startswith(('paprium/gamedata/','paprium/saves/','paprium/conf/')): continue
   zi=zipfile.ZipInfo(arc,(2026,10,18,0,0,0)); zi.create_system=3
   zi.external_attr=((0o100755 if arc.endswith(('.sh','.aarch64')) else 0o100644)<<16)
   zi.compress_type=zipfile.ZIP_DEFLATED
   z.writestr(zi,f.read_bytes())
 for directory in ['paprium/gamedata/','paprium/gamedata/paprium/','paprium/saves/','paprium/conf/']:
  zi=zipfile.ZipInfo(directory,(2026,10,18,0,0,0)); zi.create_system=3; zi.external_attr=(0o40755<<16)|0x10; z.writestr(zi,b'')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert 'paprium/paprium.aarch64' in z.namelist() and 'paprium/source.tar.gz' in z.namelist()
 assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in z.namelist())
sha=hashlib.sha256(archive.read_bytes()).hexdigest()
(dist/'SHA256SUMS.txt').write_text(sha+'  '+archive.name+'\n')
print(info)
print(archive,archive.stat().st_size,'bytes',sha)

