from pathlib import Path
import subprocess,os,shutil,hashlib,wave,array,math,json
p=Path(__file__).resolve().parents[1];t=p/'build/converter-fixtures'
t.mkdir(parents=True,exist_ok=True)
for fixture in ['mono.mp3','stereo.mp3','reference.wav']:
 shutil.copy2(p/'tests/converter-fixtures'/fixture,t/fixture)
sdk=p/'tools/aarch64--glibc--stable-2020.08-1'
root=subprocess.check_output([str(sdk/'bin/aarch64-buildroot-linux-gnu-gcc'),'-print-sysroot'],text=True).strip()
cmd=['qemu-aarch64','-L',root,str(p/'build/aarch64/paprium-convert')]
results=[]
def run(args,code=0):
 r=subprocess.run(cmd+list(map(str,args)),capture_output=True,text=True,timeout=30)
 assert r.returncode==code,(r.returncode,r.stderr)
 return r
for name in ['mono','stereo']:
 out=t/(name+'.wav')
 if out.exists():out.unlink()
 run([t/(name+'.mp3'),out]);run(['--check',out])
 with wave.open(str(out),'rb') as w:
  assert (w.getnchannels(),w.getframerate(),w.getsampwidth())==(2,48000,2)
  assert abs(w.getnframes()-14400)<=2,(name,w.getnframes())
 with wave.open(str(out),'rb') as w:
  data=array.array('h',w.readframes(w.getnframes()))
  assert sum(x*x for x in data)>100000
 results.append(name+' decoding and PCM48 stereo output')
with wave.open(str(t/'mono.wav'),'rb') as w:a=array.array('h',w.readframes(w.getnframes()))
with wave.open(str(t/'reference.wav'),'rb') as w:b=array.array('h',w.readframes(w.getnframes()))
n=min(len(a),len(b));corr=sum(a[i]*b[i] for i in range(n))/math.sqrt(sum(x*x for x in a[:n])*sum(x*x for x in b[:n]))
assert corr>0.98,corr
results.append('44.1-to-48kHz reference correlation '+str(round(corr,6)))
existing=t/'mono.wav';before=hashlib.sha256(existing.read_bytes()).digest();run([t/'stereo.mp3',existing]);assert hashlib.sha256(existing.read_bytes()).digest()==before
bad=t/'bad.mp3';bad.write_bytes(b'not an MP3');run([bad,t/'bad.wav'],3);assert not (t/'bad.wav').exists()
results+=['existing WAV preserved','invalid MP3 rejected without final WAV']
# Run the real preparation helper against generated data and the ARM64 converter.
game=t/'game';music=game/'gamedata/paprium';music.mkdir(parents=True,exist_ok=True)
wrapper=game/'paprium-convert.aarch64';wrapper.write_text('#!/bin/bash\nexec '+ ' '.join(["'"+x.replace("'","'\\''")+"'" for x in cmd])+ ' "$@"\n');wrapper.chmod(0o755)
(game/'music-tracks.txt').write_text("One's tune\nSecond\n")
shutil.copy2(t/'mono.mp3',music/"One's tune.mp3")
for name in ["One's tune.wav",'Second.wav','Second.mp3']:
 f=music/name
 if f.exists():f.unlink()
helper=['bash',str(p/'package/prepare-music.sh'),str(game)]
r=subprocess.run(helper,capture_output=True,text=True,timeout=30);assert r.returncode!=0;assert not (music/"One's tune.wav").exists()
shutil.copy2(t/'stereo.mp3',music/'Second.mp3')
hashes=[hashlib.sha256(f.read_bytes()).digest() for f in [music/"One's tune.mp3",music/'Second.mp3']]
r=subprocess.run(helper,capture_output=True,text=True,timeout=30);assert r.returncode==0,r.stdout+r.stderr
files=[music/"One's tune.wav",music/'Second.wav'];saved=[(f.stat().st_mtime_ns,hashlib.sha256(f.read_bytes()).digest()) for f in files]
(music/'Second.mp3').unlink()
r=subprocess.run(helper,capture_output=True,text=True,timeout=30);assert r.returncode==0,r.stdout+r.stderr
assert saved==[(f.stat().st_mtime_ns,hashlib.sha256(f.read_bytes()).digest()) for f in files]
assert hashlib.sha256((music/"One's tune.mp3").read_bytes()).digest()==hashes[0]
(music/'Second.wav').unlink();shutil.copy2(t/'stereo.mp3',music/'Second.mp3')
r=subprocess.run(helper,capture_output=True,text=True,timeout=30);assert r.returncode==0,r.stdout+r.stderr
assert saved[0]==(files[0].stat().st_mtime_ns,hashlib.sha256(files[0].read_bytes()).digest())
assert not list(music.glob('*.tmp.*')) and not (music/'.paprium-conversion-lock').exists()
# Failed preparation must leave prior tracks intact and release its lock.
(music/'Second.wav').unlink(); (music/'Second.mp3').write_bytes(b'invalid MP3')
r=subprocess.run(helper,capture_output=True,text=True,timeout=30);assert r.returncode!=0
assert not (music/'Second.wav').exists() and not (music/'.paprium-conversion-lock').exists()
assert saved[0]==(files[0].stat().st_mtime_ns,hashlib.sha256(files[0].read_bytes()).digest())
shutil.copy2(t/'stereo.mp3',music/'Second.mp3')
lock=music/'.paprium-conversion-lock';lock.mkdir();(lock/'owner').write_text('999999999 previous-boot\n')
r=subprocess.run(helper,capture_output=True,text=True,timeout=30);assert r.returncode==0,r.stdout+r.stderr
assert not lock.exists() and (music/'Second.wav').exists()
results+=['failed conversion releases lock and preserves completed WAV','stale lock recovery and successful retry']
results+=['missing MP3 preflight','spaces/apostrophes in names','complete WAV set skips conversion without MP3','only missing track converted','MP3 preserved and no leftover temporary files']
(p/'logs/converter-tests.json').write_text(json.dumps({'passed':True,'checks':results},indent=2)+'\n')
for result in results:print('PASS',result,flush=True)
