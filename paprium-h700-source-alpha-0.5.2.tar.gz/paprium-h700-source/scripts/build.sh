#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")/.."
export MAKEFLAGS="--jobserver-style=pipe"
export TMPDIR="$PWD/build/tmp"
mkdir -p "$TMPDIR"
python3 scripts/configure.py
cmake -S . -B build/aarch64 -DCMAKE_TOOLCHAIN_FILE="$PWD/scripts/aarch64.cmake" -DCMAKE_BUILD_TYPE=Release
cmake --build build/aarch64 --target paprium paprium-convert -j4
