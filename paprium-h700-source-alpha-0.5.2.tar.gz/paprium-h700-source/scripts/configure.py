from pathlib import Path
import re
p=Path(__file__).resolve().parents[1]
r=p/'upstream/punchium'
# Bind the firmware's SDL2 ABI at runtime; no build-only SDL library is shipped.
syms=sorted(set(re.findall(r'\b(SDL_\w+)\s*\(', (p/'src/main.c').read_text())))
syms=[s for s in syms if s not in ['SDL_VERSION']]
h=['#include <dlfcn.h>','#include <string.h>']
for s in syms: h.append(f'static __typeof__(&{s}) pm_{s};')
h.append('static int load_sdl(void) {\n void *lib = dlopen("libSDL2-2.0.so.0", RTLD_NOW | RTLD_LOCAL);\n if (!lib) { fprintf(stderr, "SDL2 unavailable: %s\\n", dlerror()); return 0; }')
for s in syms:
 h.append(f' void *sym_{s} = dlsym(lib, "{s}");\n if (!sym_{s}) {{ fprintf(stderr, "SDL2 missing: {s}\\n"); return 0; }}\n memcpy(&pm_{s}, &sym_{s}, sizeof pm_{s});')
h.append('return 1;\n}')
for s in syms: h.append(f'#define {s} pm_{s}')
(p/'src/sdl_dynamic.h').write_text('\n'.join(h)+'\n')
# Match the known SDL2 upstream object list, rather than globbing alternative CPUs/frontends.
names=list(dict.fromkeys(re.findall(r'\$\(OBJDIR\)/([\w]+)\.o',(r/'sdl/Makefile.sdl2').read_text())))
sources=[]
for n in names:
 if n in ['main','icon']: continue
 matches=list((r/'core').rglob(n+'.c'))+list((r/'sdl').glob(n+'.c'))
 if not matches: raise RuntimeError('Source missing: '+n)
 
 if '/libchdr/' not in str(matches[0]) and '/tremor/' not in str(matches[0]):
  sources.append(str(matches[0].relative_to(p)))
sources.append('upstream/punchium/core/cart_hw/stb_vorbis_my.c')
incs=['core','core/z80','core/m68k','core/sound','core/input_hw','core/cart_hw','core/cart_hw/svp','core/cd_hw','core/ntsc','core/tremor','sdl','sdl/sdl2','core/cd_hw/libchdr/src','core/cd_hw/libchdr/deps/libFLAC/include','core/cd_hw/libchdr/deps/lzma','core/cd_hw/libchdr/deps/zlib']
(p/'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.16)
project(paprium C)
set(CMAKE_C_STANDARD 99)
set(CMAKE_C_EXTENSIONS ON)
set(ZLIB_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
add_subdirectory(upstream/zlib EXCLUDE_FROM_ALL)
add_executable(paprium src/main.c
'''+ '\n'.join(sources)+''')
target_include_directories(paprium PRIVATE src upstream/SDL/include
'''+ '\n'.join('upstream/punchium/'+i for i in incs)+''')
target_compile_definitions(paprium PRIVATE LSB_FIRST USE_16BPP_RENDERING MAXROMSIZE=33554432 HAVE_YM3438_CORE HAVE_OPLL_CORE HAVE_ALLOCA_H ENABLE_SUB_68K_ADDRESS_ERROR_EXCEPTIONS PACKAGE_VERSION="1.3.2" FLAC_API_EXPORTS FLAC__HAS_OGG=0 HAVE_LROUND HAVE_STDINT_H HAVE_SYS_PARAM_H _7ZIP_ST)
target_compile_options(paprium PRIVATE -O2 -fomit-frame-pointer -fno-strict-aliasing -include ${CMAKE_CURRENT_SOURCE_DIR}/src/platform.h)
target_link_libraries(paprium PRIVATE zlibstatic m dl)
''')
print('Generated build manifest and SDL2 bindings')

with (p/'CMakeLists.txt').open('a') as f:
 f.write("\nadd_executable(paprium-convert src/convert.c)\ntarget_include_directories(paprium-convert PRIVATE upstream/punchium/core/cart_hw)\ntarget_compile_options(paprium-convert PRIVATE -O2)\ntarget_link_libraries(paprium-convert PRIVATE m)\n")
