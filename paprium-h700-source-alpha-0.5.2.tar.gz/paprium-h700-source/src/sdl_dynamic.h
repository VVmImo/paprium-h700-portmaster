#include <dlfcn.h>
#include <string.h>
static __typeof__(&SDL_ClearQueuedAudio) pm_SDL_ClearQueuedAudio;
static __typeof__(&SDL_CloseAudioDevice) pm_SDL_CloseAudioDevice;
static __typeof__(&SDL_CreateRenderer) pm_SDL_CreateRenderer;
static __typeof__(&SDL_CreateTexture) pm_SDL_CreateTexture;
static __typeof__(&SDL_CreateWindow) pm_SDL_CreateWindow;
static __typeof__(&SDL_Delay) pm_SDL_Delay;
static __typeof__(&SDL_DestroyRenderer) pm_SDL_DestroyRenderer;
static __typeof__(&SDL_DestroyTexture) pm_SDL_DestroyTexture;
static __typeof__(&SDL_DestroyWindow) pm_SDL_DestroyWindow;
static __typeof__(&SDL_GameControllerClose) pm_SDL_GameControllerClose;
static __typeof__(&SDL_GameControllerGetAttached) pm_SDL_GameControllerGetAttached;
static __typeof__(&SDL_GameControllerGetAxis) pm_SDL_GameControllerGetAxis;
static __typeof__(&SDL_GameControllerGetButton) pm_SDL_GameControllerGetButton;
static __typeof__(&SDL_GameControllerGetJoystick) pm_SDL_GameControllerGetJoystick;
static __typeof__(&SDL_GameControllerName) pm_SDL_GameControllerName;
static __typeof__(&SDL_GameControllerOpen) pm_SDL_GameControllerOpen;
static __typeof__(&SDL_GetCurrentAudioDriver) pm_SDL_GetCurrentAudioDriver;
static __typeof__(&SDL_GetCurrentVideoDriver) pm_SDL_GetCurrentVideoDriver;
static __typeof__(&SDL_GetError) pm_SDL_GetError;
static __typeof__(&SDL_GetKeyboardState) pm_SDL_GetKeyboardState;
static __typeof__(&SDL_GetPerformanceCounter) pm_SDL_GetPerformanceCounter;
static __typeof__(&SDL_GetPerformanceFrequency) pm_SDL_GetPerformanceFrequency;
static __typeof__(&SDL_GetQueuedAudioSize) pm_SDL_GetQueuedAudioSize;
static __typeof__(&SDL_GetTicks) pm_SDL_GetTicks;
static __typeof__(&SDL_Init) pm_SDL_Init;
static __typeof__(&SDL_IsGameController) pm_SDL_IsGameController;
static __typeof__(&SDL_JoystickGetDeviceInstanceID) pm_SDL_JoystickGetDeviceInstanceID;
static __typeof__(&SDL_JoystickInstanceID) pm_SDL_JoystickInstanceID;
static __typeof__(&SDL_JoystickUpdate) pm_SDL_JoystickUpdate;
static __typeof__(&SDL_NumJoysticks) pm_SDL_NumJoysticks;
static __typeof__(&SDL_OpenAudioDevice) pm_SDL_OpenAudioDevice;
static __typeof__(&SDL_PauseAudioDevice) pm_SDL_PauseAudioDevice;
static __typeof__(&SDL_PollEvent) pm_SDL_PollEvent;
static __typeof__(&SDL_PumpEvents) pm_SDL_PumpEvents;
static __typeof__(&SDL_QueueAudio) pm_SDL_QueueAudio;
static __typeof__(&SDL_Quit) pm_SDL_Quit;
static __typeof__(&SDL_RenderClear) pm_SDL_RenderClear;
static __typeof__(&SDL_RenderCopy) pm_SDL_RenderCopy;
static __typeof__(&SDL_RenderPresent) pm_SDL_RenderPresent;
static __typeof__(&SDL_RenderSetLogicalSize) pm_SDL_RenderSetLogicalSize;
static __typeof__(&SDL_SetRenderDrawColor) pm_SDL_SetRenderDrawColor;
static __typeof__(&SDL_ShowCursor) pm_SDL_ShowCursor;
static __typeof__(&SDL_UpdateTexture) pm_SDL_UpdateTexture;
static int load_sdl(void) {
 void *lib = dlopen("libSDL2-2.0.so.0", RTLD_NOW | RTLD_LOCAL);
 if (!lib) { fprintf(stderr, "SDL2 unavailable: %s\n", dlerror()); return 0; }
 void *sym_SDL_ClearQueuedAudio = dlsym(lib, "SDL_ClearQueuedAudio");
 if (!sym_SDL_ClearQueuedAudio) { fprintf(stderr, "SDL2 missing: SDL_ClearQueuedAudio\n"); return 0; }
 memcpy(&pm_SDL_ClearQueuedAudio, &sym_SDL_ClearQueuedAudio, sizeof pm_SDL_ClearQueuedAudio);
 void *sym_SDL_CloseAudioDevice = dlsym(lib, "SDL_CloseAudioDevice");
 if (!sym_SDL_CloseAudioDevice) { fprintf(stderr, "SDL2 missing: SDL_CloseAudioDevice\n"); return 0; }
 memcpy(&pm_SDL_CloseAudioDevice, &sym_SDL_CloseAudioDevice, sizeof pm_SDL_CloseAudioDevice);
 void *sym_SDL_CreateRenderer = dlsym(lib, "SDL_CreateRenderer");
 if (!sym_SDL_CreateRenderer) { fprintf(stderr, "SDL2 missing: SDL_CreateRenderer\n"); return 0; }
 memcpy(&pm_SDL_CreateRenderer, &sym_SDL_CreateRenderer, sizeof pm_SDL_CreateRenderer);
 void *sym_SDL_CreateTexture = dlsym(lib, "SDL_CreateTexture");
 if (!sym_SDL_CreateTexture) { fprintf(stderr, "SDL2 missing: SDL_CreateTexture\n"); return 0; }
 memcpy(&pm_SDL_CreateTexture, &sym_SDL_CreateTexture, sizeof pm_SDL_CreateTexture);
 void *sym_SDL_CreateWindow = dlsym(lib, "SDL_CreateWindow");
 if (!sym_SDL_CreateWindow) { fprintf(stderr, "SDL2 missing: SDL_CreateWindow\n"); return 0; }
 memcpy(&pm_SDL_CreateWindow, &sym_SDL_CreateWindow, sizeof pm_SDL_CreateWindow);
 void *sym_SDL_Delay = dlsym(lib, "SDL_Delay");
 if (!sym_SDL_Delay) { fprintf(stderr, "SDL2 missing: SDL_Delay\n"); return 0; }
 memcpy(&pm_SDL_Delay, &sym_SDL_Delay, sizeof pm_SDL_Delay);
 void *sym_SDL_DestroyRenderer = dlsym(lib, "SDL_DestroyRenderer");
 if (!sym_SDL_DestroyRenderer) { fprintf(stderr, "SDL2 missing: SDL_DestroyRenderer\n"); return 0; }
 memcpy(&pm_SDL_DestroyRenderer, &sym_SDL_DestroyRenderer, sizeof pm_SDL_DestroyRenderer);
 void *sym_SDL_DestroyTexture = dlsym(lib, "SDL_DestroyTexture");
 if (!sym_SDL_DestroyTexture) { fprintf(stderr, "SDL2 missing: SDL_DestroyTexture\n"); return 0; }
 memcpy(&pm_SDL_DestroyTexture, &sym_SDL_DestroyTexture, sizeof pm_SDL_DestroyTexture);
 void *sym_SDL_DestroyWindow = dlsym(lib, "SDL_DestroyWindow");
 if (!sym_SDL_DestroyWindow) { fprintf(stderr, "SDL2 missing: SDL_DestroyWindow\n"); return 0; }
 memcpy(&pm_SDL_DestroyWindow, &sym_SDL_DestroyWindow, sizeof pm_SDL_DestroyWindow);
 void *sym_SDL_GameControllerClose = dlsym(lib, "SDL_GameControllerClose");
 if (!sym_SDL_GameControllerClose) { fprintf(stderr, "SDL2 missing: SDL_GameControllerClose\n"); return 0; }
 memcpy(&pm_SDL_GameControllerClose, &sym_SDL_GameControllerClose, sizeof pm_SDL_GameControllerClose);
 void *sym_SDL_GameControllerGetAttached = dlsym(lib, "SDL_GameControllerGetAttached");
 if (!sym_SDL_GameControllerGetAttached) { fprintf(stderr, "SDL2 missing: SDL_GameControllerGetAttached\n"); return 0; }
 memcpy(&pm_SDL_GameControllerGetAttached, &sym_SDL_GameControllerGetAttached, sizeof pm_SDL_GameControllerGetAttached);
 void *sym_SDL_GameControllerGetAxis = dlsym(lib, "SDL_GameControllerGetAxis");
 if (!sym_SDL_GameControllerGetAxis) { fprintf(stderr, "SDL2 missing: SDL_GameControllerGetAxis\n"); return 0; }
 memcpy(&pm_SDL_GameControllerGetAxis, &sym_SDL_GameControllerGetAxis, sizeof pm_SDL_GameControllerGetAxis);
 void *sym_SDL_GameControllerGetButton = dlsym(lib, "SDL_GameControllerGetButton");
 if (!sym_SDL_GameControllerGetButton) { fprintf(stderr, "SDL2 missing: SDL_GameControllerGetButton\n"); return 0; }
 memcpy(&pm_SDL_GameControllerGetButton, &sym_SDL_GameControllerGetButton, sizeof pm_SDL_GameControllerGetButton);
 void *sym_SDL_GameControllerGetJoystick = dlsym(lib, "SDL_GameControllerGetJoystick");
 if (!sym_SDL_GameControllerGetJoystick) { fprintf(stderr, "SDL2 missing: SDL_GameControllerGetJoystick\n"); return 0; }
 memcpy(&pm_SDL_GameControllerGetJoystick, &sym_SDL_GameControllerGetJoystick, sizeof pm_SDL_GameControllerGetJoystick);
 void *sym_SDL_GameControllerName = dlsym(lib, "SDL_GameControllerName");
 if (!sym_SDL_GameControllerName) { fprintf(stderr, "SDL2 missing: SDL_GameControllerName\n"); return 0; }
 memcpy(&pm_SDL_GameControllerName, &sym_SDL_GameControllerName, sizeof pm_SDL_GameControllerName);
 void *sym_SDL_GameControllerOpen = dlsym(lib, "SDL_GameControllerOpen");
 if (!sym_SDL_GameControllerOpen) { fprintf(stderr, "SDL2 missing: SDL_GameControllerOpen\n"); return 0; }
 memcpy(&pm_SDL_GameControllerOpen, &sym_SDL_GameControllerOpen, sizeof pm_SDL_GameControllerOpen);
 void *sym_SDL_GetCurrentAudioDriver = dlsym(lib, "SDL_GetCurrentAudioDriver");
 if (!sym_SDL_GetCurrentAudioDriver) { fprintf(stderr, "SDL2 missing: SDL_GetCurrentAudioDriver\n"); return 0; }
 memcpy(&pm_SDL_GetCurrentAudioDriver, &sym_SDL_GetCurrentAudioDriver, sizeof pm_SDL_GetCurrentAudioDriver);
 void *sym_SDL_GetCurrentVideoDriver = dlsym(lib, "SDL_GetCurrentVideoDriver");
 if (!sym_SDL_GetCurrentVideoDriver) { fprintf(stderr, "SDL2 missing: SDL_GetCurrentVideoDriver\n"); return 0; }
 memcpy(&pm_SDL_GetCurrentVideoDriver, &sym_SDL_GetCurrentVideoDriver, sizeof pm_SDL_GetCurrentVideoDriver);
 void *sym_SDL_GetError = dlsym(lib, "SDL_GetError");
 if (!sym_SDL_GetError) { fprintf(stderr, "SDL2 missing: SDL_GetError\n"); return 0; }
 memcpy(&pm_SDL_GetError, &sym_SDL_GetError, sizeof pm_SDL_GetError);
 void *sym_SDL_GetKeyboardState = dlsym(lib, "SDL_GetKeyboardState");
 if (!sym_SDL_GetKeyboardState) { fprintf(stderr, "SDL2 missing: SDL_GetKeyboardState\n"); return 0; }
 memcpy(&pm_SDL_GetKeyboardState, &sym_SDL_GetKeyboardState, sizeof pm_SDL_GetKeyboardState);
 void *sym_SDL_GetPerformanceCounter = dlsym(lib, "SDL_GetPerformanceCounter");
 if (!sym_SDL_GetPerformanceCounter) { fprintf(stderr, "SDL2 missing: SDL_GetPerformanceCounter\n"); return 0; }
 memcpy(&pm_SDL_GetPerformanceCounter, &sym_SDL_GetPerformanceCounter, sizeof pm_SDL_GetPerformanceCounter);
 void *sym_SDL_GetPerformanceFrequency = dlsym(lib, "SDL_GetPerformanceFrequency");
 if (!sym_SDL_GetPerformanceFrequency) { fprintf(stderr, "SDL2 missing: SDL_GetPerformanceFrequency\n"); return 0; }
 memcpy(&pm_SDL_GetPerformanceFrequency, &sym_SDL_GetPerformanceFrequency, sizeof pm_SDL_GetPerformanceFrequency);
 void *sym_SDL_GetQueuedAudioSize = dlsym(lib, "SDL_GetQueuedAudioSize");
 if (!sym_SDL_GetQueuedAudioSize) { fprintf(stderr, "SDL2 missing: SDL_GetQueuedAudioSize\n"); return 0; }
 memcpy(&pm_SDL_GetQueuedAudioSize, &sym_SDL_GetQueuedAudioSize, sizeof pm_SDL_GetQueuedAudioSize);
 void *sym_SDL_GetTicks = dlsym(lib, "SDL_GetTicks");
 if (!sym_SDL_GetTicks) { fprintf(stderr, "SDL2 missing: SDL_GetTicks\n"); return 0; }
 memcpy(&pm_SDL_GetTicks, &sym_SDL_GetTicks, sizeof pm_SDL_GetTicks);
 void *sym_SDL_Init = dlsym(lib, "SDL_Init");
 if (!sym_SDL_Init) { fprintf(stderr, "SDL2 missing: SDL_Init\n"); return 0; }
 memcpy(&pm_SDL_Init, &sym_SDL_Init, sizeof pm_SDL_Init);
 void *sym_SDL_IsGameController = dlsym(lib, "SDL_IsGameController");
 if (!sym_SDL_IsGameController) { fprintf(stderr, "SDL2 missing: SDL_IsGameController\n"); return 0; }
 memcpy(&pm_SDL_IsGameController, &sym_SDL_IsGameController, sizeof pm_SDL_IsGameController);
 void *sym_SDL_JoystickGetDeviceInstanceID = dlsym(lib, "SDL_JoystickGetDeviceInstanceID");
 if (!sym_SDL_JoystickGetDeviceInstanceID) { fprintf(stderr, "SDL2 missing: SDL_JoystickGetDeviceInstanceID\n"); return 0; }
 memcpy(&pm_SDL_JoystickGetDeviceInstanceID, &sym_SDL_JoystickGetDeviceInstanceID, sizeof pm_SDL_JoystickGetDeviceInstanceID);
 void *sym_SDL_JoystickInstanceID = dlsym(lib, "SDL_JoystickInstanceID");
 if (!sym_SDL_JoystickInstanceID) { fprintf(stderr, "SDL2 missing: SDL_JoystickInstanceID\n"); return 0; }
 memcpy(&pm_SDL_JoystickInstanceID, &sym_SDL_JoystickInstanceID, sizeof pm_SDL_JoystickInstanceID);
 void *sym_SDL_JoystickUpdate = dlsym(lib, "SDL_JoystickUpdate");
 if (!sym_SDL_JoystickUpdate) { fprintf(stderr, "SDL2 missing: SDL_JoystickUpdate\n"); return 0; }
 memcpy(&pm_SDL_JoystickUpdate, &sym_SDL_JoystickUpdate, sizeof pm_SDL_JoystickUpdate);
 void *sym_SDL_NumJoysticks = dlsym(lib, "SDL_NumJoysticks");
 if (!sym_SDL_NumJoysticks) { fprintf(stderr, "SDL2 missing: SDL_NumJoysticks\n"); return 0; }
 memcpy(&pm_SDL_NumJoysticks, &sym_SDL_NumJoysticks, sizeof pm_SDL_NumJoysticks);
 void *sym_SDL_OpenAudioDevice = dlsym(lib, "SDL_OpenAudioDevice");
 if (!sym_SDL_OpenAudioDevice) { fprintf(stderr, "SDL2 missing: SDL_OpenAudioDevice\n"); return 0; }
 memcpy(&pm_SDL_OpenAudioDevice, &sym_SDL_OpenAudioDevice, sizeof pm_SDL_OpenAudioDevice);
 void *sym_SDL_PauseAudioDevice = dlsym(lib, "SDL_PauseAudioDevice");
 if (!sym_SDL_PauseAudioDevice) { fprintf(stderr, "SDL2 missing: SDL_PauseAudioDevice\n"); return 0; }
 memcpy(&pm_SDL_PauseAudioDevice, &sym_SDL_PauseAudioDevice, sizeof pm_SDL_PauseAudioDevice);
 void *sym_SDL_PollEvent = dlsym(lib, "SDL_PollEvent");
 if (!sym_SDL_PollEvent) { fprintf(stderr, "SDL2 missing: SDL_PollEvent\n"); return 0; }
 memcpy(&pm_SDL_PollEvent, &sym_SDL_PollEvent, sizeof pm_SDL_PollEvent);
 void *sym_SDL_PumpEvents = dlsym(lib, "SDL_PumpEvents");
 if (!sym_SDL_PumpEvents) { fprintf(stderr, "SDL2 missing: SDL_PumpEvents\n"); return 0; }
 memcpy(&pm_SDL_PumpEvents, &sym_SDL_PumpEvents, sizeof pm_SDL_PumpEvents);
 void *sym_SDL_QueueAudio = dlsym(lib, "SDL_QueueAudio");
 if (!sym_SDL_QueueAudio) { fprintf(stderr, "SDL2 missing: SDL_QueueAudio\n"); return 0; }
 memcpy(&pm_SDL_QueueAudio, &sym_SDL_QueueAudio, sizeof pm_SDL_QueueAudio);
 void *sym_SDL_Quit = dlsym(lib, "SDL_Quit");
 if (!sym_SDL_Quit) { fprintf(stderr, "SDL2 missing: SDL_Quit\n"); return 0; }
 memcpy(&pm_SDL_Quit, &sym_SDL_Quit, sizeof pm_SDL_Quit);
 void *sym_SDL_RenderClear = dlsym(lib, "SDL_RenderClear");
 if (!sym_SDL_RenderClear) { fprintf(stderr, "SDL2 missing: SDL_RenderClear\n"); return 0; }
 memcpy(&pm_SDL_RenderClear, &sym_SDL_RenderClear, sizeof pm_SDL_RenderClear);
 void *sym_SDL_RenderCopy = dlsym(lib, "SDL_RenderCopy");
 if (!sym_SDL_RenderCopy) { fprintf(stderr, "SDL2 missing: SDL_RenderCopy\n"); return 0; }
 memcpy(&pm_SDL_RenderCopy, &sym_SDL_RenderCopy, sizeof pm_SDL_RenderCopy);
 void *sym_SDL_RenderPresent = dlsym(lib, "SDL_RenderPresent");
 if (!sym_SDL_RenderPresent) { fprintf(stderr, "SDL2 missing: SDL_RenderPresent\n"); return 0; }
 memcpy(&pm_SDL_RenderPresent, &sym_SDL_RenderPresent, sizeof pm_SDL_RenderPresent);
 void *sym_SDL_RenderSetLogicalSize = dlsym(lib, "SDL_RenderSetLogicalSize");
 if (!sym_SDL_RenderSetLogicalSize) { fprintf(stderr, "SDL2 missing: SDL_RenderSetLogicalSize\n"); return 0; }
 memcpy(&pm_SDL_RenderSetLogicalSize, &sym_SDL_RenderSetLogicalSize, sizeof pm_SDL_RenderSetLogicalSize);
 void *sym_SDL_SetRenderDrawColor = dlsym(lib, "SDL_SetRenderDrawColor");
 if (!sym_SDL_SetRenderDrawColor) { fprintf(stderr, "SDL2 missing: SDL_SetRenderDrawColor\n"); return 0; }
 memcpy(&pm_SDL_SetRenderDrawColor, &sym_SDL_SetRenderDrawColor, sizeof pm_SDL_SetRenderDrawColor);
 void *sym_SDL_ShowCursor = dlsym(lib, "SDL_ShowCursor");
 if (!sym_SDL_ShowCursor) { fprintf(stderr, "SDL2 missing: SDL_ShowCursor\n"); return 0; }
 memcpy(&pm_SDL_ShowCursor, &sym_SDL_ShowCursor, sizeof pm_SDL_ShowCursor);
 void *sym_SDL_UpdateTexture = dlsym(lib, "SDL_UpdateTexture");
 if (!sym_SDL_UpdateTexture) { fprintf(stderr, "SDL2 missing: SDL_UpdateTexture\n"); return 0; }
 memcpy(&pm_SDL_UpdateTexture, &sym_SDL_UpdateTexture, sizeof pm_SDL_UpdateTexture);
return 1;
}
#define SDL_ClearQueuedAudio pm_SDL_ClearQueuedAudio
#define SDL_CloseAudioDevice pm_SDL_CloseAudioDevice
#define SDL_CreateRenderer pm_SDL_CreateRenderer
#define SDL_CreateTexture pm_SDL_CreateTexture
#define SDL_CreateWindow pm_SDL_CreateWindow
#define SDL_Delay pm_SDL_Delay
#define SDL_DestroyRenderer pm_SDL_DestroyRenderer
#define SDL_DestroyTexture pm_SDL_DestroyTexture
#define SDL_DestroyWindow pm_SDL_DestroyWindow
#define SDL_GameControllerClose pm_SDL_GameControllerClose
#define SDL_GameControllerGetAttached pm_SDL_GameControllerGetAttached
#define SDL_GameControllerGetAxis pm_SDL_GameControllerGetAxis
#define SDL_GameControllerGetButton pm_SDL_GameControllerGetButton
#define SDL_GameControllerGetJoystick pm_SDL_GameControllerGetJoystick
#define SDL_GameControllerName pm_SDL_GameControllerName
#define SDL_GameControllerOpen pm_SDL_GameControllerOpen
#define SDL_GetCurrentAudioDriver pm_SDL_GetCurrentAudioDriver
#define SDL_GetCurrentVideoDriver pm_SDL_GetCurrentVideoDriver
#define SDL_GetError pm_SDL_GetError
#define SDL_GetKeyboardState pm_SDL_GetKeyboardState
#define SDL_GetPerformanceCounter pm_SDL_GetPerformanceCounter
#define SDL_GetPerformanceFrequency pm_SDL_GetPerformanceFrequency
#define SDL_GetQueuedAudioSize pm_SDL_GetQueuedAudioSize
#define SDL_GetTicks pm_SDL_GetTicks
#define SDL_Init pm_SDL_Init
#define SDL_IsGameController pm_SDL_IsGameController
#define SDL_JoystickGetDeviceInstanceID pm_SDL_JoystickGetDeviceInstanceID
#define SDL_JoystickInstanceID pm_SDL_JoystickInstanceID
#define SDL_JoystickUpdate pm_SDL_JoystickUpdate
#define SDL_NumJoysticks pm_SDL_NumJoysticks
#define SDL_OpenAudioDevice pm_SDL_OpenAudioDevice
#define SDL_PauseAudioDevice pm_SDL_PauseAudioDevice
#define SDL_PollEvent pm_SDL_PollEvent
#define SDL_PumpEvents pm_SDL_PumpEvents
#define SDL_QueueAudio pm_SDL_QueueAudio
#define SDL_Quit pm_SDL_Quit
#define SDL_RenderClear pm_SDL_RenderClear
#define SDL_RenderCopy pm_SDL_RenderCopy
#define SDL_RenderPresent pm_SDL_RenderPresent
#define SDL_RenderSetLogicalSize pm_SDL_RenderSetLogicalSize
#define SDL_SetRenderDrawColor pm_SDL_SetRenderDrawColor
#define SDL_ShowCursor pm_SDL_ShowCursor
#define SDL_UpdateTexture pm_SDL_UpdateTexture
