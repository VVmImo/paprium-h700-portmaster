/* Output DC rejection only: no bass boost or treble equalization. */
#ifndef PAPRIUM_AUDIO_OUTPUT_H
#define PAPRIUM_AUDIO_OUTPUT_H
#include <stdint.h>
#include <math.h>
typedef struct { double previous_input[2], previous_output[2]; } pm_dc_blocker;
static void pm_remove_dc(pm_dc_blocker *s, int16_t *pcm, int frames) {
    /* 5 Hz at 48 kHz; 40 Hz attenuation is less than 0.07 dB. */
    const double pole = 0.9993457156679053;
    for (int i = 0; i < frames; ++i) for (int ch = 0; ch < 2; ++ch) {
        double x = pcm[i*2+ch];
        double y = x - s->previous_input[ch] + pole*s->previous_output[ch];
        s->previous_input[ch] = x; s->previous_output[ch] = y;
        long out = lrint(y);
        pcm[i*2+ch] = out > 32767 ? 32767 : out < -32768 ? -32768 : (int16_t)out;
    }
}
#endif
