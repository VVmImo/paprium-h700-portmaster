/* Unsigned ROM PCM decoding and linear reconstruction of held samples. */
#ifndef PAPRIUM_PCM_INTERPOLATE_H
#define PAPRIUM_PCM_INTERPOLATE_H
#include <stdint.h>
static int pm_decode_pcm(unsigned byte, int depth, int nibble) {
    if (depth == 1) return ((int)(byte & 255) - 128) * 256;
    return ((int)((nibble == 0 ? byte >> 4 : byte) & 15) - 8) * 4096;
}
static int pm_interpolate_pcm(int a, int b, int tick, int period) {
    return a + (int)(((int64_t)b - a) * tick / period);
}
#endif
