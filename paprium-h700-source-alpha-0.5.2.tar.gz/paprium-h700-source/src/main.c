/* Paprium SDL2 standalone frontend. See LICENSE.txt and upstream licenses. */
#include <stdbool.h>
#include <stdint.h>
#include <signal.h>
#include <errno.h>
#include <unistd.h>
#include <sys/stat.h>
#include <limits.h>
#include <SDL.h>
#include "shared.h"
#include "sms_ntsc.h"
#include "md_ntsc.h"
#include <zlib.h>
#include "sdl_dynamic.h"
#include "audio_output.h"

int debug_on, log_error;
uint8_t cart_size;
md_ntsc_t *md_ntsc;
sms_ntsc_t *sms_ntsc;
char g_rom_dir[256];
uint8_t punchium_audio_track_format = 1;
bool punchium_cheat_saitama = false;
bool punchium_tile_cache = true;
static volatile sig_atomic_t running = 1;
static int reset_requested, reset_held;
static SDL_GameController *pads[2];
static uint8_t saved_sram[65536];
static char save_path[PATH_MAX];
static int save_valid;
static void stop(int sig) { (void)sig; running = 0; }

static int save_sram(void) {
    if (save_valid && !memcmp(saved_sram, sram.sram, sizeof saved_sram)) return 0;
    char tmp[PATH_MAX];
    if (snprintf(tmp, sizeof tmp, "%s.tmp", save_path) >= (int)sizeof tmp) return -1;
    FILE *f = fopen(tmp, "wb");
    if (!f) { perror("Save open"); return -1; }
    int ok = fwrite(sram.sram, 1, sizeof saved_sram, f) == sizeof saved_sram;
    if (fflush(f) || fsync(fileno(f))) ok = 0;
    if (fclose(f)) ok = 0;
    if (!ok || rename(tmp, save_path)) { perror("Save commit"); return -1; }
    memcpy(saved_sram, sram.sram, sizeof saved_sram);
    save_valid = 1;
    fprintf(stderr, "SRAM saved: %s\n", save_path);
    return 0;
}
static int load_sram(void) {
    FILE *f = fopen(save_path, "rb");
    if (!f) {
        if (errno != ENOENT) { perror("Save read"); return -1; }
    } else {
        uint8_t data[65536];
        size_t n = fread(data, 1, sizeof data, f);
        int extra = fgetc(f), err = ferror(f);
        fclose(f);
        if (n != sizeof data || extra != EOF || err) {
            fprintf(stderr, "Invalid SRAM size; refusing to overwrite existing save\n");
            return -1;
        }
        memcpy(sram.sram, data, sizeof data);
    }
    memcpy(saved_sram, sram.sram, sizeof saved_sram);
    save_valid = 1;
    return 0;
}
static void open_pads(void) {
    for (int p = 0; p < 2; ++p) if (pads[p] && !SDL_GameControllerGetAttached(pads[p])) {
        SDL_GameControllerClose(pads[p]); pads[p] = NULL;
    }
    for (int j = 0; j < SDL_NumJoysticks(); ++j) {
        if (!SDL_IsGameController(j)) continue;
        SDL_JoystickID id = SDL_JoystickGetDeviceInstanceID(j);
        int used = 0;
        for (int p = 0; p < 2; ++p) if (pads[p] && SDL_JoystickInstanceID(SDL_GameControllerGetJoystick(pads[p])) == id) used = 1;
        if (used) continue;
        for (int p = 0; p < 2; ++p) if (!pads[p]) {
            pads[p] = SDL_GameControllerOpen(j);
            if (pads[p]) fprintf(stderr, "Pad %d: %s\n", p+1, SDL_GameControllerName(pads[p]));
            break;
        }
    }
}
int sdl_input_update(void) {
    static const SDL_GameControllerButton buttons[] = {
        SDL_CONTROLLER_BUTTON_DPAD_UP, SDL_CONTROLLER_BUTTON_DPAD_DOWN,
        SDL_CONTROLLER_BUTTON_DPAD_LEFT, SDL_CONTROLLER_BUTTON_DPAD_RIGHT,
        SDL_CONTROLLER_BUTTON_X, SDL_CONTROLLER_BUTTON_A, SDL_CONTROLLER_BUTTON_B,
        SDL_CONTROLLER_BUTTON_Y, SDL_CONTROLLER_BUTTON_LEFTSHOULDER,
        SDL_CONTROLLER_BUTTON_RIGHTSHOULDER, SDL_CONTROLLER_BUTTON_START,
        SDL_CONTROLLER_BUTTON_BACK };
    static const uint16 masks[] = { INPUT_UP, INPUT_DOWN, INPUT_LEFT, INPUT_RIGHT,
        INPUT_A, INPUT_B, INPUT_C, INPUT_X, INPUT_Y, INPUT_Z, INPUT_START, INPUT_MODE };
    for (int p = 0; p < 2; ++p) {
        input.pad[p ? 4 : 0] = 0;
        if (!pads[p]) continue;
        int quit = SDL_GameControllerGetButton(pads[p], SDL_CONTROLLER_BUTTON_BACK) &&
                   SDL_GameControllerGetButton(pads[p], SDL_CONTROLLER_BUTTON_START);
        if (quit) { running = 0; continue; }
        if (p == 0) {
            int reset_chord = SDL_GameControllerGetButton(pads[p], SDL_CONTROLLER_BUTTON_BACK) &&
                SDL_GameControllerGetButton(pads[p], SDL_CONTROLLER_BUTTON_RIGHTSHOULDER);
            if (reset_chord && !reset_held) reset_requested = 1;
            reset_held = reset_chord;
            if (reset_chord) continue;
        }
        for (unsigned j = 0; j < sizeof masks / sizeof masks[0]; ++j)
            if (SDL_GameControllerGetButton(pads[p], buttons[j])) input.pad[p ? 4 : 0] |= masks[j];
        int x = SDL_GameControllerGetAxis(pads[p], SDL_CONTROLLER_AXIS_LEFTX);
        int y = SDL_GameControllerGetAxis(pads[p], SDL_CONTROLLER_AXIS_LEFTY);
        if (x < -16000) input.pad[p ? 4 : 0] |= INPUT_LEFT;
        if (x > 16000) input.pad[p ? 4 : 0] |= INPUT_RIGHT;
        if (y < -16000) input.pad[p ? 4 : 0] |= INPUT_UP;
        if (y > 16000) input.pad[p ? 4 : 0] |= INPUT_DOWN;
    }
    const Uint8 *k = SDL_GetKeyboardState(NULL);
    static const SDL_Scancode keys[] = { SDL_SCANCODE_UP, SDL_SCANCODE_DOWN,
        SDL_SCANCODE_LEFT, SDL_SCANCODE_RIGHT, SDL_SCANCODE_A, SDL_SCANCODE_S,
        SDL_SCANCODE_D, SDL_SCANCODE_Z, SDL_SCANCODE_X, SDL_SCANCODE_C,
        SDL_SCANCODE_RETURN, SDL_SCANCODE_RSHIFT };
    for (unsigned j = 0; j < sizeof masks / sizeof masks[0]; ++j)
        if (k[keys[j]]) input.pad[0] |= masks[j];
    if (k[SDL_SCANCODE_ESCAPE]) running = 0;
    return 1;
}
static void frame(void) {
    system_frame_gen(0);
}
static int test_controller(void) {
    if (!load_sdl() || SDL_Init(SDL_INIT_GAMECONTROLLER)) return 20;
    void *lib = dlopen("libSDL2-2.0.so.0", RTLD_NOW | RTLD_LOCAL);
    __typeof__(&SDL_JoystickAttachVirtual) attach_virtual;
    __typeof__(&SDL_JoystickSetVirtualButton) set_button;
    __typeof__(&SDL_JoystickSetVirtualAxis) set_axis;
    __typeof__(&SDL_JoystickDetachVirtual) detach_virtual;
    void *sym = dlsym(lib, "SDL_JoystickAttachVirtual"); memcpy(&attach_virtual, &sym, sizeof sym);
    sym = dlsym(lib, "SDL_JoystickSetVirtualButton"); memcpy(&set_button, &sym, sizeof sym);
    sym = dlsym(lib, "SDL_JoystickSetVirtualAxis"); memcpy(&set_axis, &sym, sizeof sym);
    sym = dlsym(lib, "SDL_JoystickDetachVirtual"); memcpy(&detach_virtual, &sym, sizeof sym);
    if (!attach_virtual || !set_button || !set_axis || !detach_virtual) { SDL_Quit(); return 21; }
    int index = attach_virtual(SDL_JOYSTICK_TYPE_GAMECONTROLLER, SDL_CONTROLLER_AXIS_MAX,
        SDL_CONTROLLER_BUTTON_MAX, 0);
    if (index < 0) { fprintf(stderr, "Virtual pad: %s\n", SDL_GetError()); SDL_Quit(); return 22; }
    open_pads();
    if (!pads[0]) { SDL_Quit(); return 23; }
    int second = attach_virtual(SDL_JOYSTICK_TYPE_GAMECONTROLLER, SDL_CONTROLLER_AXIS_MAX,
        SDL_CONTROLLER_BUTTON_MAX, 0);
    open_pads();
    if (second < 0 || !pads[1]) { SDL_Quit(); return 27; }
    SDL_Joystick *joy2 = SDL_GameControllerGetJoystick(pads[1]);
    set_button(joy2, SDL_CONTROLLER_BUTTON_A, 1); SDL_PumpEvents(); SDL_JoystickUpdate();
    sdl_input_update();
    if (input.pad[4] != INPUT_B || input.pad[0]) { SDL_Quit(); return 28; }
    set_button(joy2, SDL_CONTROLLER_BUTTON_A, 0); SDL_PumpEvents(); SDL_JoystickUpdate();
    SDL_Joystick *joy = SDL_GameControllerGetJoystick(pads[0]);
    const SDL_GameControllerButton buttons[] = { SDL_CONTROLLER_BUTTON_X, SDL_CONTROLLER_BUTTON_A,
        SDL_CONTROLLER_BUTTON_B, SDL_CONTROLLER_BUTTON_Y, SDL_CONTROLLER_BUTTON_LEFTSHOULDER,
        SDL_CONTROLLER_BUTTON_RIGHTSHOULDER, SDL_CONTROLLER_BUTTON_START, SDL_CONTROLLER_BUTTON_BACK,
        SDL_CONTROLLER_BUTTON_DPAD_UP, SDL_CONTROLLER_BUTTON_DPAD_DOWN,
        SDL_CONTROLLER_BUTTON_DPAD_LEFT, SDL_CONTROLLER_BUTTON_DPAD_RIGHT };
    const uint16 masks[] = { INPUT_A, INPUT_B, INPUT_C, INPUT_X, INPUT_Y, INPUT_Z,
        INPUT_START, INPUT_MODE, INPUT_UP, INPUT_DOWN, INPUT_LEFT, INPUT_RIGHT };
    for (unsigned i = 0; i < sizeof masks / sizeof masks[0]; ++i) {
        set_button(joy, buttons[i], 1); SDL_PumpEvents(); SDL_JoystickUpdate();
        sdl_input_update();
        if (input.pad[0] != masks[i]) { fprintf(stderr, "Input mismatch %u: %x\n", i, input.pad[0]); SDL_Quit(); return 24; }
        set_button(joy, buttons[i], 0); SDL_PumpEvents(); SDL_JoystickUpdate();
    }
    set_axis(joy, SDL_CONTROLLER_AXIS_LEFTX, -20000); SDL_PumpEvents(); SDL_JoystickUpdate();
    sdl_input_update();
    if (input.pad[0] != INPUT_LEFT) { SDL_Quit(); return 25; }
    set_axis(joy, SDL_CONTROLLER_AXIS_LEFTX, 0);
    set_button(joy, SDL_CONTROLLER_BUTTON_BACK, 1); set_button(joy, SDL_CONTROLLER_BUTTON_RIGHTSHOULDER, 1);
    SDL_PumpEvents(); SDL_JoystickUpdate(); sdl_input_update();
    if (!reset_requested || input.pad[0]) { SDL_Quit(); return 29; }
    reset_requested = 0; sdl_input_update();
    if (reset_requested) { SDL_Quit(); return 30; }
    set_button(joy, SDL_CONTROLLER_BUTTON_RIGHTSHOULDER, 0);
    set_button(joy, SDL_CONTROLLER_BUTTON_BACK, 0); SDL_PumpEvents(); SDL_JoystickUpdate(); sdl_input_update();
    set_button(joy, SDL_CONTROLLER_BUTTON_BACK, 1); set_button(joy, SDL_CONTROLLER_BUTTON_START, 1);
    SDL_PumpEvents(); SDL_JoystickUpdate(); sdl_input_update();
    if (running || input.pad[0]) { SDL_Quit(); return 26; }
    SDL_GameControllerClose(pads[1]); pads[1] = NULL;
    detach_virtual(second);
    SDL_GameControllerClose(pads[0]); pads[0] = NULL;
    detach_virtual(index); SDL_Quit();
    puts("Controller tests passed: 6 buttons, dpad, start, mode, analog and graceful exit chord");
    return 0;
}
extern int pm_audio_selftest(const char *dir);
int main(int argc, char **argv) {
    if (argc == 2 && !strcmp(argv[1], "--test-controller")) return test_controller();
    if (argc == 3 && !strcmp(argv[1], "--test-wav")) return pm_audio_selftest(argv[2]);
    if (argc == 2 && !strcmp(argv[1], "--version")) {
        puts("Paprium H700 alpha 0.5.2; PUNCHiUM 3849f3d; SDL2 frontend"); return 0;
    }
    if (argc < 3 || !strcmp(argv[1], "--help")) {
        puts("Usage: paprium ROM SAVE_DIRECTORY [--frames N]\nNeeds SDL2 and user-provided ROM + paprium/*.wav.\nExit: Select+Start or Escape. SRAM autosaved every 5 seconds and at exit.");
        return (argc == 2 && !strcmp(argv[1], "--help")) ? 0 : 2;
    }
    unsigned long limit = 0;
    if (argc == 5 && !strcmp(argv[3], "--frames")) {
        char *end; errno = 0; limit = strtoul(argv[4], &end, 10);
        if (errno || *end || !limit || limit > 10000000) return 2;
    } else if (argc != 3) return 2;
    char rom[PATH_MAX];
    if (!realpath(argv[1], rom)) { perror("ROM"); return 2; }
    if (strlen(rom) >= sizeof g_rom_dir) { fputs("ROM path too long\n", stderr); return 2; }
    strcpy(g_rom_dir, rom);
    char *slash = strrchr(g_rom_dir, '/');
    if (slash) *slash = 0;
    if (mkdir(argv[2], 0755) && errno != EEXIST) { perror("Save directory"); return 2; }
    if (snprintf(save_path, sizeof save_path, "%s/paprium.srm", argv[2]) >= (int)sizeof save_path) return 2;
    if (!load_sdl()) return 3;
    signal(SIGTERM, stop); signal(SIGINT, stop);
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_GAMECONTROLLER)) {
        fprintf(stderr, "SDL init: %s\n", SDL_GetError()); return 3;
    }
    fprintf(stderr, "SDL video=%s audio=%s\n", SDL_GetCurrentVideoDriver(), SDL_GetCurrentAudioDriver());
    SDL_Window *window = SDL_CreateWindow("Paprium", SDL_WINDOWPOS_CENTERED,
        SDL_WINDOWPOS_CENTERED, 640, 480, SDL_WINDOW_FULLSCREEN_DESKTOP);
    SDL_Renderer *renderer = window ? SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED) : NULL;
    if (!renderer && window) renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_SOFTWARE);
    SDL_Texture *texture = renderer ? SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGB565,
        SDL_TEXTUREACCESS_STREAMING, 720, 576) : NULL;
    if (!texture) { fprintf(stderr, "SDL video: %s\n", SDL_GetError()); SDL_Quit(); return 3; }
    SDL_RenderSetLogicalSize(renderer, 640, 480);
    SDL_ShowCursor(SDL_DISABLE);
    SDL_AudioSpec desired = {0}, actual = {0};
    desired.freq = 48000; desired.format = AUDIO_S16SYS;
    desired.channels = 2; desired.samples = 1024;
    SDL_AudioDeviceID audio = SDL_OpenAudioDevice(NULL, 0, &desired, &actual, 0);
    if (!audio) { fprintf(stderr, "SDL audio: %s\n", SDL_GetError()); SDL_Quit(); return 3; }
    set_config_defaults();
    /* External PCM music should not inherit the legacy console low-pass. */
    const char *legacy_filter = getenv("PAPRIUM_LEGACY_AUDIO_FILTER");
    config.filter = (legacy_filter && !strcmp(legacy_filter, "1")) ? 1 : 0;
    fprintf(stderr, "Paprium audio: filter=%s, output=%dHz/%uch/%04x\n",
        config.filter ? "legacy low-pass" : "off", actual.freq,
        (unsigned)actual.channels, (unsigned)actual.format);
    fputs("Audio quality: DC rejection 5Hz, interpolated ROM PCM, 50ms queue priming\n", stderr);
    config.input[0].padtype = config.input[1].padtype = DEVICE_PAD6B;
    memset(&bitmap, 0, sizeof bitmap);
    bitmap.width = 720; bitmap.height = 576; bitmap.pitch = 720 * 2;
    bitmap.data = calloc(576, bitmap.pitch);
    if (!bitmap.data) { SDL_Quit(); return 4; }
    memset(boot_rom, 0xff, 0x800); system_bios = 0;
    if (!load_rom(rom) || system_hw != SYSTEM_MD) {
        fputs("Invalid Mega Drive ROM\n", stderr); SDL_Quit(); free(bitmap.data); return 2;
    }
    if (!limit && !strstr(rominfo.product, "T-574120-00")) {
        fputs("This build expects a Paprium-compatible T-574120-00 dump\n", stderr);
        SDL_Quit(); free(bitmap.data); return 2;
    }
    if (audio_init(48000, 0) < 0) { SDL_Quit(); free(bitmap.data); return 4; }
    system_init(); system_reset();
    if (load_sram()) { audio_shutdown(); SDL_Quit(); free(bitmap.data); return 4; }
    open_pads();
    /* Prime three frames before starting playback to absorb short SD stalls. */
    uint64_t freq = SDL_GetPerformanceFrequency(), next = SDL_GetPerformanceCounter();
    double fps = vdp_pal ? 50.0 : 59.922743;
    uint64_t step = (uint64_t)(freq / fps);
    unsigned long frames = 0;
    Uint32 last_save = SDL_GetTicks();
    int result = 0;
    pm_dc_blocker dc = {0};
    int audio_started = 0;
    int16_t pcm[4096];
    const char *capture_path = getenv("PAPRIUM_AUDIO_CAPTURE");
    FILE *capture = capture_path ? fopen(capture_path, "wb") : NULL;
    uint64_t audio_samples = 0, audio_clipped = 0;
    unsigned audio_queue_resets = 0, audio_underruns = 0;
    if (capture_path && !capture) { perror("Audio capture"); running = 0; result = 4; }

    while (running && (!limit || frames < limit)) {
        SDL_Event ev;
        while (SDL_PollEvent(&ev)) {
            if (ev.type == SDL_QUIT) running = 0;
            if (ev.type == SDL_KEYDOWN && ev.key.keysym.sym == SDLK_F1) reset_requested = 1;
            if (ev.type == SDL_CONTROLLERDEVICEADDED || ev.type == SDL_CONTROLLERDEVICEREMOVED) open_pads();
        }
        if (!running) break;
        frame();
        const char *test_reset = limit ? getenv("PAPRIUM_TEST_RESET_FRAME") : NULL;
        if (test_reset && frames + 1 == strtoul(test_reset, NULL, 10)) reset_requested = 1;
        if (reset_requested) {
            reset_requested = 0;
            if (save_sram()) result = 4;
            gen_reset(0);
            SDL_PauseAudioDevice(audio, 1);
            audio_started = 0;
            memset(&dc, 0, sizeof dc);
            SDL_ClearQueuedAudio(audio);
            fprintf(stderr, "Mega Drive soft reset at frame %lu\n", frames + 1);
        }
        int samples = audio_update(pcm);
        if (samples < 0 || samples > 2048) { fputs("Invalid audio frame size\n", stderr); result = 4; break; }
        pm_remove_dc(&dc, pcm, samples);
        for (int i = 0; i < samples * 2; ++i)
            if (pcm[i] == INT16_MIN || pcm[i] == INT16_MAX) audio_clipped++;
        audio_samples += samples * 2;
        if (capture && fwrite(pcm, 4, samples, capture) != (size_t)samples) {
            perror("Audio capture write"); result = 4; break;
        }
        Uint32 queued = SDL_GetQueuedAudioSize(audio);
        if (audio_started && !queued) audio_underruns++;
        /* Bound latency after slow I/O or a track transition. */
        if (queued > 48000 * 4 / 8) {
            SDL_PauseAudioDevice(audio, 1); audio_started = 0;
            SDL_ClearQueuedAudio(audio); audio_queue_resets++;
        }
        if (SDL_QueueAudio(audio, pcm, (Uint32)samples * 4)) { result = 3; break; }
        if (!audio_started && SDL_GetQueuedAudioSize(audio) >= 2400 * 4) {
            SDL_PauseAudioDevice(audio, 0); audio_started = 1;
        }
        SDL_Rect source = {0, 0, bitmap.viewport.w + 2*bitmap.viewport.x, bitmap.viewport.h + 2*bitmap.viewport.y};
        if (source.w <= 0 || source.h <= 0 || source.w > 720 || source.h > 576) { result = 4; break; }
        if (SDL_UpdateTexture(texture, NULL, bitmap.data, bitmap.pitch)) { result = 3; break; }
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255); SDL_RenderClear(renderer);
        SDL_RenderCopy(renderer, texture, &source, NULL); SDL_RenderPresent(renderer);
        frames++;
        Uint32 now_ms = SDL_GetTicks();
        if (now_ms - last_save >= 5000) {
            if (save_sram()) result = 4;
            last_save = now_ms;
        }
        next += step;
        uint64_t now = SDL_GetPerformanceCounter();
        if (next > now) SDL_Delay((Uint32)((next-now)*1000/freq));
        else if (now-next > freq/4) next = now;
    }
    if (save_sram()) result = 4;
    fprintf(stderr, "Frames=%lu result=%d framebuffer_crc=%08lx first_pixel=%04x sram_marker=%02x\n", frames, result,
        (unsigned long)crc32(0, bitmap.data, bitmap.pitch * bitmap.height),
        ((uint16_t *)bitmap.data)[0], sram.sram[1]);
    if (capture && fclose(capture)) result = 4;
    fprintf(stderr, "Audio diagnostics: samples=%llu clipped=%llu queue_resets=%u underrun_frames=%u\n",
        (unsigned long long)audio_samples, (unsigned long long)audio_clipped,
        audio_queue_resets, audio_underruns);
    SDL_CloseAudioDevice(audio); audio_shutdown();
    for (int p = 0; p < 2; ++p) if (pads[p]) SDL_GameControllerClose(pads[p]);
    SDL_DestroyTexture(texture); SDL_DestroyRenderer(renderer); SDL_DestroyWindow(window);
    SDL_Quit(); free(bitmap.data);
    return result;
}
