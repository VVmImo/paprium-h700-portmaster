/* SFX-only 6 kHz Butterworth reconstruction filter at 48 kHz. */
#ifndef PAPRIUM_SFX_FILTER_H
#define PAPRIUM_SFX_FILTER_H
#include <math.h>
typedef struct { double z1[2], z2[2]; } pm_sfx_filter;
static void pm_filter_sfx(pm_sfx_filter *s, int *left, int *right) {
    int *channels[2] = {left, right};
    for (int ch = 0; ch < 2; ++ch) {
        double x = *channels[ch];
        double y = 0.0976310729378175*x + s->z1[ch];
        s->z1[ch] = 0.195262145875635*x + 0.942809041582063*y + s->z2[ch];
        s->z2[ch] = 0.0976310729378175*x - 0.333333333333333*y;
        *channels[ch] = (int)lrint(y);
    }
}
#endif
