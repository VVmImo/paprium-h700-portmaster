/* MP3-to-WAV helper. Distributed under the project's non-commercial license.
 * Decoder: minimp3 (CC0); WAV writer: dr_wav (MIT-0/public domain).
 */
#define _FILE_OFFSET_BITS 64
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include <unistd.h>
#include <limits.h>
#include <fcntl.h>
#define MINIMP3_IMPLEMENTATION
#include "minimp3_ex.h"
#define DR_WAV_IMPLEMENTATION
#include "dr_wav.h"
static volatile sig_atomic_t cancelled;
static void cancel(int sig) { (void)sig; cancelled = 1; }
static size_t read_mp3(void *buf, size_t size, void *user) { return fread(buf, 1, size, user); }
static int seek_mp3(uint64_t pos, void *user) { return fseeko(user, (off_t)pos, SEEK_SET); }
typedef struct { mp3dec_ex_t *dec; short pcm[8192]; size_t used, count; int channels; } reader;
static int next_frame(reader *r, short dst[2]) {
    if (r->used == r->count) {
        r->count = mp3dec_ex_read(r->dec, r->pcm, 8192);
        r->used = 0;
        if (!r->count) return 0;
    }
    if (r->count-r->used < (size_t)r->channels) return 0;
    dst[0] = r->pcm[r->used++];
    dst[1] = r->channels == 2 ? r->pcm[r->used++] : dst[0];
    return 1;
}
static int check_wav(const char *path) {
    drwav w;
    if (!drwav_init_file(&w, path, NULL)) return 1;
    int ok = w.totalPCMFrameCount && w.channels >= 1 && w.channels <= 2 &&
        w.sampleRate >= 8000 && w.sampleRate <= 48000;
    short sample[2];
    if (ok) ok = drwav_seek_to_pcm_frame(&w, w.totalPCMFrameCount-1) &&
                 drwav_read_pcm_frames_s16(&w, 1, sample) == 1;
    drwav_uninit(&w);
    return ok ? 0 : 1;
}
int main(int argc, char **argv) {
    if (argc == 3 && !strcmp(argv[1], "--check")) return check_wav(argv[2]);
    if (argc != 3) { fputs("Usage: paprium-convert INPUT.mp3 OUTPUT.wav\n       paprium-convert --check FILE.wav\n", stderr); return 2; }
    if (!access(argv[2], F_OK)) {
        fprintf(stderr, "Output already exists; preserving: %s\n", argv[2]);
        return check_wav(argv[2]);
    }
    signal(SIGINT, cancel); signal(SIGTERM, cancel);
    FILE *input = fopen(argv[1], "rb");
    if (!input) { perror("MP3 open"); return 3; }
    mp3dec_ex_t dec = {0};
    mp3dec_io_t io = { read_mp3, input, seek_mp3, input };
    int status = mp3dec_ex_open_cb(&dec, &io, MP3D_DO_NOT_SCAN);
    if (status || dec.info.channels < 1 || dec.info.channels > 2 ||
        dec.info.hz < 8000 || dec.info.hz > 48000 || dec.info.layer != 3) {
        fprintf(stderr, "Invalid/unsupported MP3: %s (decoder=%d)\n", argv[1], status);
        mp3dec_ex_close(&dec); fclose(input); return 3;
    }
    char tmp[PATH_MAX];
    if (snprintf(tmp, sizeof tmp, "%s.tmp.%ld", argv[2], (long)getpid()) >= (int)sizeof tmp) {
        mp3dec_ex_close(&dec); fclose(input); return 3;
    }
    drwav out;
    drwav_data_format format = {drwav_container_riff, DR_WAVE_FORMAT_PCM, 2, 48000, 16};
    if (!drwav_init_file_write(&out, tmp, &format, NULL)) {
        perror("WAV open"); mp3dec_ex_close(&dec); fclose(input); return 4;
    }
    reader r = {0}; r.dec = &dec; r.channels = dec.info.channels;
    short a[2], b[2], block[8192];
    uint64_t frames = 0;
    size_t filled = 0;
    unsigned phase = 0, rate = dec.info.hz;
    int have_a = next_frame(&r, a);
    int have_b = have_a ? next_frame(&r, b) : 0;
    int ok = have_a;
    if (!have_b && have_a) memcpy(b, a, sizeof a);
    while (have_a && ok && !cancelled) {
        for (int ch = 0; ch < 2; ++ch)
            block[filled++] = (short)(((int64_t)a[ch]*(48000-phase)+(int64_t)b[ch]*phase)/48000);
        frames++;
        if (filled == 8192) {
            if (drwav_write_pcm_frames(&out, filled/2, block) != filled/2) ok = 0;
            filled = 0;
        }
        phase += rate;
        if (phase >= 48000) {
            phase -= 48000;
            if (!have_b) break;
            memcpy(a, b, sizeof a);
            have_b = next_frame(&r, b);
            if (!have_b) memcpy(b, a, sizeof a);
        }
    }
    if (filled && drwav_write_pcm_frames(&out, filled/2, block) != filled/2) ok = 0;
    if (dec.last_error || ferror(input) || cancelled) ok = 0;
    if (drwav_uninit(&out) != DRWAV_SUCCESS) ok = 0;
    mp3dec_ex_close(&dec); fclose(input);
    if (!frames) ok = 0;
    if (ok) {
        int fd = open(tmp, O_RDONLY);
        if (fd < 0) ok = 0;
        else { if (fsync(fd)) ok = 0; close(fd); }
    }
    if (ok && check_wav(tmp)) ok = 0;
    if (ok && access(argv[2], F_OK) == 0) {
        fputs("Output appeared during conversion; preserving it\n", stderr); ok = 0;
    }
    if (ok && rename(tmp, argv[2])) { perror("WAV commit"); ok = 0; }
    if (!ok) { unlink(tmp); fprintf(stderr, "Conversion failed: %s\n", argv[1]); return cancelled ? 130 : 4; }
    fprintf(stderr, "Converted: %s -> 48kHz stereo PCM16 (%llu frames)\n", argv[1], (unsigned long long)frames);
    return 0;
}
