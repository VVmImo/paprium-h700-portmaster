#!/bin/bash
set -euo pipefail
PACKAGE_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"
FILES="$PACKAGE_DIR/files"
DEST=/userdata/roms/ports
if ! grep -qi knulli /etc/os-release; then echo 'This package requires KNULLI.'; exit 1; fi
if [ "$(uname -m)" != aarch64 ]; then echo 'This package requires ARM64 / aarch64.'; exit 1; fi
if pidof paprium.aarch64 >/dev/null 2>&1; then echo 'Close Paprium before installing.'; exit 1; fi
(cd "$FILES" && sha256sum -c payload.sha256)
"$FILES/paprium/paprium.aarch64" --version
if [ -L "$DEST/paprium" ] || [ -L "$DEST/Paprium.sh" ]; then
 echo 'Paprium destination is a symbolic link; installation cancelled to preserve it.'; exit 1
fi
mkdir -p "$DEST/paprium"
cp -R "$FILES/paprium/." "$DEST/paprium/"
cp "$FILES/Paprium.sh" "$DEST/Paprium.sh"
chmod 755 "$DEST/Paprium.sh" "$DEST/paprium/"*.aarch64 "$DEST/paprium/"*.sh
mkdir -p "$DEST/paprium/gamedata/paprium" "$DEST/paprium/saves" "$DEST/paprium/conf"
sync
echo 'Installation complete in /userdata/roms/ports.'
echo 'Update gamelists, then open Paprium in Ports.'
echo 'Experimental: not hardware-tested on KNULLI.'
