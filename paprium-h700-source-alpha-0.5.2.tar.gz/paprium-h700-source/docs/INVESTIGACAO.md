# Source investigation and base selection — 2026-10-18

Remote branches observed with git ls-remote --heads:

| Repository | Branch | Observed commit |
| --- | --- | --- |
| pav1388/Genesis-Plus-GX-PUNCHiUM | punchium | 3849f3d3432df1d6320574e73695dd379ecef2b3 |
| pav1388/Genesis-Plus-GX-PUNCHiUM | rom-glitcher | b3cae6885b8520c2a9691dd369b701b9dba7bd39 |
| Genesis64X/Genesis-Plus-G64X_PAPwiiUM | main | c38719b3c442e48c93dfebe130fe58110d554395 |
| Genesis64X/Genesis-Plus-G64X_PAPwiiUM | 1 | 7b9bf7283c89009e6befbf6d3a9ac0bdf674ea7d |

The pinned punchium branch includes the cartridge mapper, resource decoding,
effects mixer and SRAM integration in core/cart_hw/punchium.h. Product identifier
T-574120-00 selects the mapper in md_cart.c. Commands 0xDF/0xE0 transfer four
0x780-byte banks between cartridge RAM and SRAM. A custom SDL2 frontend replaces
libretro. PAPwiiUM is a Wii/libogc/devkitPPC adaptation reference, not a ready-made
Linux executable. Libretro PR #378 is historical context, not proof of current
upstream support. The rom-glitcher branch has a different purpose.

Changes include bounded-memory WAV streaming, corrected format-array bounds,
stdio logging and bounded round-robin tile replacement. The old memset did not
initialize the uint32_t hash sentinel correctly and replacement could loop at
the age boundary. Runtime requirements are Linux ARM64/glibc, firmware SDL2
video/audio/GameController support and PortMaster helpers/mappings. CHD and
Mega-CD OGG handling are disabled. Other Mega-CD modules remain compiled for
internal dependencies, while this frontend accepts Mega Drive and targets Paprium.

Version 0.5.1 corrects per-voice effects amplification and adds an effects-only
reconstruction filter. Version 0.5.2 changes project documentation and installer
language to English without changing audio behavior. KNULLI is hardware-untested.

Sources:
- https://github.com/pav1388/Genesis-Plus-GX-PUNCHiUM/tree/punchium
- https://github.com/libretro/Genesis-Plus-GX/pull/378
- https://github.com/Genesis64X/Genesis-Plus-G64X_PAPwiiUM
- https://portmaster.games/packaging.html
- https://toolchains.bootlin.com/downloads/releases/toolchains/aarch64/tarballs/
